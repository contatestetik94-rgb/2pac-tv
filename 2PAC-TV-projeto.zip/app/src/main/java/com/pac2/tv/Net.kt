package com.pac2.tv

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetAddress
import java.util.concurrent.TimeUnit

/** Cliente de rede do app. Pode usar DNS Cloudflare ou Google (consultas criptografadas, DNS sobre HTTPS). */
object Net {
    @Volatile var client: OkHttpClient = build("system")

    private fun build(mode: String): OkHttpClient {
        val base = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true).followSslRedirects(true).retryOnConnectionFailure(true).build()
        val doh: DnsOverHttps? = when (mode) {
            "cloudflare" -> DnsOverHttps.Builder().client(base).url("https://cloudflare-dns.com/dns-query".toHttpUrl())
                .bootstrapDnsHosts(InetAddress.getByName("1.1.1.1"), InetAddress.getByName("1.0.0.1")).build()
            "google" -> DnsOverHttps.Builder().client(base).url("https://dns.google/dns-query".toHttpUrl())
                .bootstrapDnsHosts(InetAddress.getByName("8.8.8.8"), InetAddress.getByName("8.8.4.4")).build()
            else -> null
        }
        if (doh == null) return base
        // se o DNS escolhido falhar, cai para o DNS do aparelho (o app não fica sem rede)
        val dns = object : Dns {
            override fun lookup(hostname: String): List<InetAddress> =
                try { doh.lookup(hostname) } catch (e: Exception) { Dns.SYSTEM.lookup(hostname) }
        }
        return base.newBuilder().dns(dns).build()
    }

    fun set(mode: String) { client = build(mode) }
}
