package com.pac2.tv

import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

data class Program(val title: String, val desc: String, val start: Long, val end: Long)

object Session { @Volatile var x: Xtream? = null }

/** Guia de programação (EPG) com cache de 5 minutos. */
object Epg {
    private val cache = HashMap<String, Pair<Long, List<Program>>>()
    private val sem = Semaphore(4)
    suspend fun get(ch: Channel): List<Program> {
        val now = System.currentTimeMillis()
        val hit = synchronized(cache) { cache[ch.url] }
        if (hit != null && now - hit.first < 300000L) return hit.second
        val x = Session.x ?: return emptyList()
        val r = sem.withPermit { withContext(Dispatchers.IO) { try { x.shortEpg(ch, 6) } catch (_: Exception) { emptyList<Program>() } } }
        synchronized(cache) { cache[ch.url] = now to r }
        return r
    }
}

/** Busca a capa no painel quando o filme/série veio sem imagem. */
object Covers {
    private val cache = HashMap<String, String>()
    private val sem = Semaphore(3)
    suspend fun get(ch: Channel): String? {
        val hit = synchronized(cache) { cache[ch.url] }
        if (hit != null) return hit.ifEmpty { null }
        val x = Session.x ?: return null
        val r = sem.withPermit { withContext(Dispatchers.IO) { try { x.cover(ch) } catch (_: Exception) { null } } } ?: ""
        synchronized(cache) { cache[ch.url] = r }
        return r.ifEmpty { null }
    }
}

private val hdRe = Regex("""(^|[^A-Z0-9])(FULL ?HD|FHD|UHD|4K|HD|H\.?265|HEVC)([^A-Z0-9]|$)""")
private val sdRe = Regex("""(^|[^A-Z0-9])SD([^A-Z0-9]|$)""")

fun isHd(c: Channel): Boolean {
    val n = c.name.uppercase()
    val hdName = hdRe.containsMatchIn(n)
    if (sdRe.containsMatchIn(n) && !hdName) return false
    return hdName || hdRe.containsMatchIn(c.group.uppercase())
}

/** Mantém só canais HD / Full HD / 4K. Se o painel não marcar a qualidade, não esconde tudo. */
fun applyQuality(list: List<Channel>): List<Channel> {
    val live = list.count { it.type == LIVE }
    val kept = list.filter { it.type != LIVE || isHd(it) }
    val keptLive = kept.count { it.type == LIVE }
    return if (live >= 10 && keptLive < 10) list else kept
}

fun liveUrl(u: String, fmt: String?): String =
    if (fmt == "m3u8" && "/live/" in u && u.endsWith(".ts")) u.removeSuffix(".ts") + ".m3u8"
    else if (fmt == "ts" && "/live/" in u && u.endsWith(".m3u8")) u.removeSuffix(".m3u8") + ".ts"
    else u

/** Favoritos e histórico guardados no aparelho. */
object Store {
    private const val SEP = '\u001F'
    private fun enc(c: Channel) = listOf(c.name, c.logo ?: "", c.group, c.type.toString(), c.url, c.show ?: "")
        .joinToString(separator = SEP.toString()) { it.replace(SEP, ' ').replace('\n', ' ') }
    private fun dec(s: String): Channel? {
        val p = s.split(SEP)
        if (p.size < 6) return null
        return Channel(p[0], p[4], p[1].ifBlank { null }, p[2], p[3].toIntOrNull() ?: 0, p[5].ifBlank { null })
    }
    fun load(prefs: SharedPreferences, key: String): List<Channel> =
        (prefs.getString(key, "") ?: "").split('\n').mapNotNull { if (it.isBlank()) null else dec(it) }
    fun save(prefs: SharedPreferences, key: String, list: List<Channel>, max: Int) {
        prefs.edit().putString(key, list.take(max).joinToString(separator = "\n") { enc(it) }).apply()
    }
}
