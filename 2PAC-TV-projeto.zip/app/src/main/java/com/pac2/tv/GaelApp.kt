package com.pac2.tv

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

class GaelApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Net.set(getSharedPreferences("p", 0).getString("dns", "system") ?: "system")
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .callFactory(object : okhttp3.Call.Factory {
            override fun newCall(request: okhttp3.Request): okhttp3.Call = Net.client.newCall(request)
        })
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.22).build() }
        .diskCache { DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(200L * 1024 * 1024).build() }
        .crossfade(false).allowRgb565(true).respectCacheHeaders(false).build()
}
