package com.pac2.tv

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

val Bg = Color(0xFF07060F)
val Cyan = Color(0xFF00F0FF)
val Pink = Color(0xFFFF2BD6)

val Gold = Color(0xFFFFC21A)
val GoldHi = Color(0xFFFFE066)

fun neonTitle(size: Float = 40f) = buildAnnotatedString {
    withStyle(SpanStyle(color = GoldHi, shadow = Shadow(Gold, Offset.Zero, size))) { append("GAEL ") }
    withStyle(SpanStyle(color = Gold, shadow = Shadow(Color(0xFFFF9A00), Offset.Zero, size))) { append("TV") }
}

@Composable
fun NeonButton(text: String, onClick: () -> Unit) {
    Text(text, Modifier.neon(onClick).padding(horizontal = 20.dp, vertical = 12.dp), color = Color.White, fontWeight = FontWeight.SemiBold)
}

@Composable
fun PlayerScreen(list: List<Channel>, start: Int, live: Boolean, onExit: () -> Unit) {
    val ctx = LocalContext.current
    var idx by remember { mutableIntStateOf(start) }
    val player = remember {
        val http = DefaultHttpDataSource.Factory().setUserAgent("Mozilla/5.0 2PACTV")
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(10000).setReadTimeoutMs(15000)
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 2500, 5000).build())
            .build()
    }
    LaunchedEffect(idx) {
        player.setMediaItem(MediaItem.fromUri(list[idx].url)); player.prepare(); player.playWhenReady = true
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler(onBack = onExit)
    var showName by remember { mutableStateOf(true) }
    LaunchedEffect(idx) { showName = true; delay(3500); showName = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = true
                keepScreenOn = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                isFocusable = true
                setOnKeyListener { v, code, ev ->
                    if (ev.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    val pv = v as PlayerView
                    val up = code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_UP ||
                        (live && code == KeyEvent.KEYCODE_DPAD_UP && !pv.isControllerFullyVisible)
                    val down = code == KeyEvent.KEYCODE_CHANNEL_DOWN || code == KeyEvent.KEYCODE_PAGE_DOWN ||
                        (live && code == KeyEvent.KEYCODE_DPAD_DOWN && !pv.isControllerFullyVisible)
                    when {
                        up -> { idx = (idx + 1) % list.size; true }
                        down -> { idx = (idx - 1 + list.size) % list.size; true }
                        else -> false
                    }
                }
                post { requestFocus() }
            }
        })
        AnimatedVisibility(showName, Modifier.align(Alignment.TopStart).padding(32.dp)) {
            Text(list[idx].name, color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(Color(0x99000000), RoundedCornerShape(10.dp)).padding(14.dp, 8.dp))
        }
    }
}
