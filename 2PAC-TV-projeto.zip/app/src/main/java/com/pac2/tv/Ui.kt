package com.pac2.tv

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

val Bg = Color(0xFF07060F)
val Cyan = Color(0xFF00F0FF)
val Pink = Color(0xFFFF2BD6)

fun neonTitle(size: Float = 40f) = buildAnnotatedString {
    withStyle(SpanStyle(color = Pink, shadow = Shadow(Pink, Offset.Zero, size))) { append("2PAC ") }
    withStyle(SpanStyle(color = Cyan, shadow = Shadow(Cyan, Offset.Zero, size))) { append("TV") }
}

@Composable
fun IntroScreen(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        repeat(3) { a.snapTo(0.15f); delay(90); a.snapTo(0.8f); delay(70) }
        a.animateTo(1f, tween(500)); delay(1500); onDone()
    }
    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF1A0530), Bg))), Alignment.Center) {
        Column(Modifier.alpha(a.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(neonTitle(60f), fontSize = 88.sp, fontWeight = FontWeight.Black, letterSpacing = 8.sp)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.width(300.dp).height(4.dp).background(Cyan, RoundedCornerShape(2.dp)))
            Spacer(Modifier.height(12.dp))
            Text("STREAMING", color = Color.White.copy(alpha = 0.7f), letterSpacing = 10.sp, fontSize = 16.sp)
        }
    }
}

fun Modifier.neon(onClick: () -> Unit, radius: Int = 14): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(radius.dp)
    this.onFocusChanged { f = it.isFocused }
        .scale(if (f) 1.06f else 1f)
        .border(if (f) 3.dp else 1.dp, if (f) Cyan else Color(0x33FFFFFF), shape)
        .clip(shape)
        .background(if (f) Color(0x3300F0FF) else Color(0x22FFFFFF))
        .clickable(onClick = onClick)
}

@Composable
fun NeonButton(text: String, onClick: () -> Unit) {
    Text(text, Modifier.neon(onClick).padding(horizontal = 20.dp, vertical = 12.dp), color = Color.White, fontWeight = FontWeight.SemiBold)
}

@Composable
fun HomeScreen(
    channels: List<Channel>, loading: Boolean, error: String?, savedUrl: String,
    onUrl: (String) -> Unit, onFile: () -> Unit, onPlay: (List<Channel>, Int) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("Todos") }
    var dialog by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf(savedUrl) }
    val groups = remember(channels) { listOf("Todos") + channels.map { it.group }.distinct() }
    val shown = remember(channels, query, group) {
        channels.filter { (group == "Todos" || it.group == group) && it.name.contains(query, true) }
    }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF1A0530)))).padding(32.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(neonTitle(30f), fontSize = 36.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            NeonButton("Carregar lista (URL)") { dialog = true }
            Spacer(Modifier.width(12.dp))
            NeonButton("Abrir arquivo M3U", onFile)
        }
        Spacer(Modifier.height(16.dp))
        if (channels.isNotEmpty()) {
            OutlinedTextField(query, { query = it }, label = { Text("Buscar canal") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(groups) { g ->
                    Text(g, Modifier.neon({ group = g }, 20).padding(horizontal = 16.dp, vertical = 8.dp),
                        color = if (g == group) Cyan else Color.White)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Cyan) }
            error != null -> Text(error, color = Pink)
            channels.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("Carregue sua lista M3U por URL ou arquivo para começar.", color = Color.White.copy(alpha = 0.7f), fontSize = 20.sp)
            }
            else -> LazyVerticalGrid(GridCells.Adaptive(170.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(shown.size) { i ->
                    val ch = shown[i]
                    Column(Modifier.neon({ onPlay(shown, i) })) {
                        Box(Modifier.fillMaxWidth().height(100.dp), Alignment.Center) {
                            if (ch.logo != null) AsyncImage(ch.logo, null, Modifier.fillMaxSize().padding(10.dp), contentScale = ContentScale.Fit)
                            else Text("▶", color = Cyan, fontSize = 32.sp)
                        }
                        Text(ch.name, Modifier.padding(10.dp), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
    if (dialog) AlertDialog(
        onDismissRequest = { dialog = false },
        title = { Text("URL da lista M3U") },
        text = { OutlinedTextField(url, { url = it }, singleLine = true, placeholder = { Text("http://...") }) },
        confirmButton = { TextButton({ if (url.isNotBlank()) onUrl(url.trim()); dialog = false }) { Text("Carregar") } },
        dismissButton = { TextButton({ dialog = false }) { Text("Cancelar") } }
    )
}

@Composable
fun PlayerScreen(list: List<Channel>, start: Int, onExit: () -> Unit) {
    val ctx = LocalContext.current
    var idx by remember { mutableIntStateOf(start) }
    val player = remember {
        val http = DefaultHttpDataSource.Factory().setUserAgent("Mozilla/5.0 2PACTV")
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(10000).setReadTimeoutMs(15000)
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(15000, 50000, 2500, 5000).build())
            .build()
    }
    LaunchedEffect(idx) {
        player.setMediaItem(MediaItem.fromUri(list[idx].url)); player.prepare(); player.playWhenReady = true
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler(onBack = onExit)
    var showName by remember { mutableStateOf(true) }
    LaunchedEffect(idx) { showName = true; delay(3500); showName = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = true
                keepScreenOn = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                isFocusable = true
                setOnKeyListener { v, code, ev ->
                    if (ev.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    val pv = v as PlayerView
                    val up = code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_UP ||
                        (code == KeyEvent.KEYCODE_DPAD_UP && !pv.isControllerFullyVisible)
                    val down = code == KeyEvent.KEYCODE_CHANNEL_DOWN || code == KeyEvent.KEYCODE_PAGE_DOWN ||
                        (code == KeyEvent.KEYCODE_DPAD_DOWN && !pv.isControllerFullyVisible)
                    when {
                        up -> { idx = (idx + 1) % list.size; true }
                        down -> { idx = (idx - 1 + list.size) % list.size; true }
                        else -> false
                    }
                }
                post { requestFocus() }
            }
        })
        AnimatedVisibility(showName, Modifier.align(Alignment.TopStart).padding(32.dp)) {
            Text(list[idx].name, color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(Color(0x99000000), RoundedCornerShape(10.dp)).padding(14.dp, 8.dp))
        }
    }
}
