package com.pac2.tv

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

val Bg = Color(0xFF07060F)
val Cyan = Color(0xFF00F0FF)
val Pink = Color(0xFFFF2BD6)

val Gold = Color(0xFFFFC21A)
val GoldHi = Color(0xFFFFE066)
val FocusBlue = Color(0xFF3D8BFF)

fun neonTitle(size: Float = 40f) = buildAnnotatedString {
    withStyle(SpanStyle(color = GoldHi, shadow = Shadow(Gold, Offset.Zero, size))) { append("GAEL ") }
    withStyle(SpanStyle(color = Gold, shadow = Shadow(Color(0xFFFF9A00), Offset.Zero, size))) { append("TV") }
}

fun Modifier.neon(onClick: () -> Unit, radius: Int = 14, onFocus: (() -> Unit)? = null): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val f by src.collectIsFocusedAsState()
    LaunchedEffect(f) { if (f) onFocus?.invoke() }
    val shape = RoundedCornerShape(radius.dp)
    this.scale(if (f) 1.08f else 1f)
        .clip(shape)
        .background(if (f) Color(0x333D8BFF) else Color(0x22FFFFFF))
        .clickable(interactionSource = src, indication = null, onClick = onClick)
        .drawWithContent {
            drawContent()
            val r = CornerRadius(radius.dp.toPx())
            fun ring(w: Float, c: Color) = drawRoundRect(c, Offset(w / 2, w / 2), Size(size.width - w, size.height - w), r, style = Stroke(w))
            if (f) { ring(9.dp.toPx(), FocusBlue.copy(alpha = 0.35f)); ring(4.dp.toPx(), FocusBlue) } else ring(1.dp.toPx(), Color(0x33FFFFFF))
        }
}

@Composable
fun NeonButton(text: String, onClick: () -> Unit) {
    Text(text, Modifier.neon(onClick).padding(horizontal = 20.dp, vertical = 12.dp), color = Color.White, fontWeight = FontWeight.SemiBold)
}

