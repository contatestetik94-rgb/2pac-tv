package com.pac2.tv

import java.io.BufferedReader

data class Channel(val name: String, val url: String, val logo: String?, val group: String)

object M3uParser {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    fun parse(reader: BufferedReader, limit: Int = 50000): List<Channel> {
        val out = ArrayList<Channel>()
        var name = ""; var logo: String? = null; var group = "Outros"
        for (raw in reader.lineSequence()) {
            val l = raw.trim()
            if (l.startsWith("#EXTINF")) {
                val m = attr.findAll(l).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                logo = m["tvg-logo"]?.ifBlank { null }
                group = m["group-title"]?.ifBlank { null } ?: "Outros"
                name = l.substringAfterLast(',', "").trim().ifBlank { m["tvg-name"] ?: "Canal" }
            } else if (l.isNotEmpty() && !l.startsWith("#")) {
                out.add(Channel(name.ifBlank { "Canal ${out.size + 1}" }, l, logo, group))
                name = ""; logo = null; group = "Outros"
                if (out.size >= limit) break
            }
        }
        return out
    }
}
