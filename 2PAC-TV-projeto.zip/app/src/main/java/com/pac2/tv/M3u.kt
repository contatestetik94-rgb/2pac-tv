package com.pac2.tv

import java.io.BufferedReader

const val LIVE = 0
const val MOVIE = 1
const val SERIES = 2

data class Channel(val name: String, val url: String, val logo: String?, val group: String, val type: Int = LIVE, val show: String? = null)

object M3uParser {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val ep = Regex("""^(.*?)[\s._-]*[Ss](\d{1,2})\s*[Ee](\d{1,3})""")

    private fun kind(url: String, group: String, name: String): Int {
        val u = url.lowercase(); val g = group.lowercase()
        return when {
            "/series/" in u -> SERIES
            "/movie/" in u -> MOVIE
            ".m3u8" in u || u.endsWith(".ts") -> LIVE
            "serie" in g || "série" in g || "novela" in g -> SERIES
            "filme" in g || "movie" in g || "vod" in g || "cinema" in g || "lançamento" in g -> MOVIE
            ep.containsMatchIn(name) -> SERIES
            u.endsWith(".mp4") || u.endsWith(".mkv") || u.endsWith(".avi") -> MOVIE
            else -> LIVE
        }
    }

    fun parse(reader: BufferedReader, limit: Int = 150000): List<Channel> {
        val out = ArrayList<Channel>()
        var name = ""; var logo: String? = null; var group = "Outros"
        for (raw in reader.lineSequence()) {
            val l = raw.trim()
            if (l.startsWith("#EXTINF")) {
                val m = attr.findAll(l).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                logo = m["tvg-logo"]?.ifBlank { null }
                group = (m["group-title"]?.ifBlank { null } ?: "Outros").intern()
                name = l.substringAfterLast(',', "").trim().ifBlank { m["tvg-name"] ?: "Canal" }
            } else if (l.isNotEmpty() && !l.startsWith("#")) {
                val n = name.ifBlank { "Canal ${out.size + 1}" }
                val t = kind(l, group, n)
                val show = if (t == SERIES) (ep.find(n)?.groupValues?.get(1)?.trim()?.ifBlank { null } ?: n).intern() else null
                out.add(Channel(n, l, logo, group, t, show))
                name = ""; logo = null; group = "Outros"
                if (out.size >= limit) break
            }
        }
        return out
    }
}
