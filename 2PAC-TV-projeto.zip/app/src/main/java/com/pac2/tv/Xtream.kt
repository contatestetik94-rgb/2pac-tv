package com.pac2.tv

import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class Xtream(server: String, val user: String, val pass: String) {
    val base: String = server.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }
    private fun e(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun api(action: String = "", extra: String = "") =
        "$base/player_api.php?username=${e(user)}&password=${e(pass)}" + (if (action.isEmpty()) "" else "&action=$action") + extra

    private fun open(url: String): InputStream {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 GAELTV")
        return c.inputStream
    }

    private fun forEachObj(url: String, f: (Map<String, String>) -> Unit) {
        JsonReader(open(url).bufferedReader()).use { r ->
            if (r.peek() != JsonToken.BEGIN_ARRAY) { r.skipValue(); return }
            r.beginArray()
            while (r.hasNext()) {
                val m = HashMap<String, String>()
                r.beginObject()
                while (r.hasNext()) {
                    val k = r.nextName()
                    when (r.peek()) {
                        JsonToken.STRING, JsonToken.NUMBER -> m[k] = r.nextString()
                        JsonToken.NULL -> r.nextNull()
                        else -> r.skipValue()
                    }
                }
                r.endObject(); f(m)
            }
            r.endArray()
        }
    }

    /** Confere usuário/senha. Retorna a validade (timestamp) ou lança erro. */
    fun check(): String {
        val txt = open(api()).bufferedReader().use { it.readText() }
        val ui = JSONObject(txt).optJSONObject("user_info") ?: throw Exception("Servidor inválido")
        if (ui.optString("auth") != "1") throw Exception("Usuário ou senha inválidos")
        return ui.optString("exp_date")
    }

    private fun cats(a: String): Map<String, String> {
        val m = HashMap<String, String>()
        try { forEachObj(api(a)) { m[it["category_id"] ?: ""] = it["category_name"] ?: "Outros" } } catch (_: Exception) {}
        return m
    }

    fun load(): List<Channel> {
        val out = ArrayList<Channel>()
        try {
            val lc = cats("get_live_categories")
            forEachObj(api("get_live_streams")) { m ->
                val id = m["stream_id"] ?: return@forEachObj
                out.add(Channel(m["name"] ?: "Canal", "$base/live/$user/$pass/$id.ts", m["stream_icon"]?.ifBlank { null },
                    (lc[m["category_id"]] ?: "Canais").intern(), LIVE))
            }
        } catch (_: Exception) {}
        try {
            val vc = cats("get_vod_categories")
            forEachObj(api("get_vod_streams")) { m ->
                val id = m["stream_id"] ?: return@forEachObj
                val ext = m["container_extension"]?.ifBlank { null } ?: "mp4"
                out.add(Channel(m["name"] ?: "Filme", "$base/movie/$user/$pass/$id.$ext", m["stream_icon"]?.ifBlank { null },
                    (vc[m["category_id"]] ?: "Filmes").intern(), MOVIE))
            }
        } catch (_: Exception) {}
        try {
            val sc = cats("get_series_categories")
            forEachObj(api("get_series")) { m ->
                val id = m["series_id"] ?: return@forEachObj
                val n = m["name"] ?: "Série"
                out.add(Channel(n, "series:$id", m["cover"]?.ifBlank { null }, (sc[m["category_id"]] ?: "Séries").intern(), SERIES, n))
            }
        } catch (_: Exception) {}
        return out
    }

    fun episodes(seriesId: String, show: String): List<Channel> {
        val txt = open(api("get_series_info", "&series_id=$seriesId")).bufferedReader().use { it.readText() }
        val eps = JSONObject(txt).opt("episodes")
        val out = ArrayList<Channel>()
        fun addSeason(season: String, arr: JSONArray) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id"); if (id.isEmpty()) continue
                val ext = o.optString("container_extension").ifBlank { "mp4" }
                val title = o.optString("title").ifBlank { "Episódio" }
                out.add(Channel("T$season E${o.optString("episode_num")} · $title", "$base/series/$user/$pass/$id.$ext", null, show, SERIES, show))
            }
        }
        if (eps is JSONObject) {
            for (k in eps.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.toList()) {
                val arr = eps.optJSONArray(k) ?: continue
                addSeason(k, arr)
            }
        } else if (eps is JSONArray) {
            for (i in 0 until eps.length()) eps.optJSONArray(i)?.let { addSeason((i + 1).toString(), it) }
        }
        return out
    }
}

/** Guarda a lista no formato M3U para abrir rápido na próxima vez. */
fun saveCache(list: List<Channel>, file: File) {
    file.bufferedWriter().use { w ->
        for (c in list) {
            w.write("#EXTINF:-1 tvg-logo=\"${(c.logo ?: "").replace("\"", "")}\" group-title=\"${c.group.replace("\"", "")}\",${c.name.replace(",", " ").replace("\n", " ")}\n${c.url}\n")
        }
    }
}
