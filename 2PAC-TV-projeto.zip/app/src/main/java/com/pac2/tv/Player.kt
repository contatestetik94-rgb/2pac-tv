package com.pac2.tv

import android.view.KeyEvent as NKey
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

private fun fmtTime(ms: Long): String {
    val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@Composable
fun PlayerScreen(list: List<Channel>, start: Int, live: Boolean, liveRows: List<Pair<String, List<Channel>>>, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var curList by remember { mutableStateOf(list) }
    var idx by remember { mutableIntStateOf(start) }
    var ratio by remember { mutableIntStateOf(prefs.getInt("ratio", 0)) }
    var speed by remember { mutableFloatStateOf(1f) }
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableLongStateOf(0L) }
    var overlay by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(true) }
    var showName by remember { mutableStateOf(true) }
    val fmt = remember { prefs.getString("fmt", "m3u8") }
    val smooth = remember { prefs.getBoolean("smooth", false) }
    val ratioNames = listOf("Ajustar", "Preencher", "Zoom")
    val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)

    val player = remember {
        val http = DefaultHttpDataSource.Factory().setUserAgent("Mozilla/5.0 GAELTV")
            .setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(10000).setReadTimeoutMs(20000)
        ExoPlayer.Builder(ctx, DefaultRenderersFactory(ctx).setEnableDecoderFallback(true))
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(DefaultLoadControl.Builder().apply {
                if (smooth) setBufferDurationsMs(40000, 120000, 5000, 10000) else setBufferDurationsMs(20000, 60000, 3000, 6000)
            }.build())
            .build().also { p ->
                var tries = 0
                p.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) { if (tries < 3) { tries++; p.prepare() } }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { if (isPlaying) tries = 0 }
                })
            }
    }
    val cur = curList[idx]
    LaunchedEffect(cur.url) {
        var u = cur.url
        if (live && fmt == "m3u8" && "/live/" in u && u.endsWith(".ts")) u = u.removeSuffix(".ts") + ".m3u8"
        player.setMediaItem(MediaItem.fromUri(u)); player.prepare(); player.playWhenReady = true; player.setPlaybackSpeed(speed)
        showName = true; delay(3500); showName = false
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(Unit) {
        while (true) {
            pos = player.currentPosition; dur = player.duration.coerceAtLeast(0L); playing = player.isPlaying
            delay(500)
        }
    }

    fun bump() { controls = true; touch = System.nanoTime() }
    fun seekBy(ms: Long) {
        val d = player.duration; val t = player.currentPosition + ms
        player.seekTo(if (d > 0) t.coerceIn(0L, d) else t.coerceAtLeast(0L))
    }
    LaunchedEffect(touch, controls, panel) { if (controls && !panel) { delay(4000); controls = false } }

    val fr = remember { FocusRequester() }
    val panelFr = remember { FocusRequester() }
    val curFr = remember { FocusRequester() }
    LaunchedEffect(overlay, panel) {
        delay(80)
        try { if (panel) panelFr.requestFocus() else if (overlay) curFr.requestFocus() else fr.requestFocus() } catch (_: Exception) {}
    }
    BackHandler { when { overlay -> overlay = false; panel -> panel = false; else -> onExit() } }

    Box(
        Modifier.fillMaxSize().background(Color.Black).focusRequester(fr).focusable()
            .pointerInput(live) {
                detectTapGestures { if (live) overlay = !overlay else { if (controls) controls = false else bump() } }
            }
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown || overlay || panel) false
                else {
                    val k = e.nativeKeyEvent.keyCode
                    val rc = e.nativeKeyEvent.repeatCount
                    when {
                        live && (k == NKey.KEYCODE_DPAD_CENTER || k == NKey.KEYCODE_ENTER) -> { overlay = true; true }
                        live && (k == NKey.KEYCODE_DPAD_UP || k == NKey.KEYCODE_CHANNEL_UP || k == NKey.KEYCODE_PAGE_UP) -> { idx = (idx + 1) % curList.size; true }
                        live && (k == NKey.KEYCODE_DPAD_DOWN || k == NKey.KEYCODE_CHANNEL_DOWN || k == NKey.KEYCODE_PAGE_DOWN) -> { idx = (idx - 1 + curList.size) % curList.size; true }
                        !live && (k == NKey.KEYCODE_DPAD_CENTER || k == NKey.KEYCODE_ENTER || k == NKey.KEYCODE_MEDIA_PLAY_PAUSE || k == NKey.KEYCODE_SPACE) -> {
                            if (player.isPlaying) player.pause() else player.play(); bump(); true
                        }
                        !live && k == NKey.KEYCODE_MEDIA_PLAY -> { player.play(); bump(); true }
                        !live && k == NKey.KEYCODE_MEDIA_PAUSE -> { player.pause(); bump(); true }
                        !live && (k == NKey.KEYCODE_DPAD_LEFT || k == NKey.KEYCODE_MEDIA_REWIND) -> { seekBy(-10_000L * minOf(6, 1 + rc / 4)); bump(); true }
                        !live && (k == NKey.KEYCODE_DPAD_RIGHT || k == NKey.KEYCODE_MEDIA_FAST_FORWARD) -> { seekBy(10_000L * minOf(6, 1 + rc / 4)); bump(); true }
                        !live && k == NKey.KEYCODE_DPAD_UP -> { bump(); true }
                        !live && k == NKey.KEYCODE_DPAD_DOWN -> { panel = true; bump(); true }
                        else -> false
                    }
                }
            }
    ) {
        AndroidView(Modifier.fillMaxSize(), factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = false
                keepScreenOn = true
                isFocusable = false
                setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            }
        }, update = { it.resizeMode = when (ratio) { 1 -> 3; 2 -> 4; else -> 0 } })

        if (showName) Text(cur.name, Modifier.align(Alignment.TopStart).padding(24.dp)
            .background(Color(0x99000000), RoundedCornerShape(10.dp)).padding(14.dp, 8.dp),
            color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)

        // ---------- controles de filme/série
        if (!live && controls && !panel) Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))).padding(24.dp)
        ) {
            Text(cur.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmtTime(pos), color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f).height(5.dp).background(Color(0x44FFFFFF), RoundedCornerShape(3.dp))) {
                    Box(Modifier.fillMaxWidth(if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f).fillMaxHeight().background(Gold, RoundedCornerShape(3.dp)))
                }
                Spacer(Modifier.width(10.dp))
                Text(fmtTime(dur), color = Color.White, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("⏪ 10s", Modifier.neon({ seekBy(-10_000L); bump() }, 12).padding(12.dp), color = Color.White)
                Text(if (playing) "⏸ Pausar" else "▶ Continuar", Modifier.neon({ if (player.isPlaying) player.pause() else player.play(); bump() }, 12).padding(12.dp), color = Gold, fontWeight = FontWeight.Bold)
                Text("10s ⏩", Modifier.neon({ seekBy(10_000L); bump() }, 12).padding(12.dp), color = Color.White)
                Text("⚙ Opções", Modifier.neon({ panel = true }, 12).padding(12.dp), color = Color.White)
            }
            Text("OK: pausar  •  ◀ ▶: voltar/avançar 10s  •  ▼: proporção e velocidade", Modifier.padding(top = 8.dp), color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
        }

        // ---------- opções (proporção / velocidade)
        if (!live && panel) Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xEE000000)).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Opções do vídeo", color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("▭ Proporção: ${ratioNames[ratio]}", Modifier.focusRequester(panelFr)
                    .neon({ ratio = (ratio + 1) % 3; prefs.edit().putInt("ratio", ratio).apply() }, 12).padding(14.dp), color = Color.White)
                Text("⏱ Velocidade: ${speed}x", Modifier
                    .neon({ speed = speeds[(speeds.indexOf(speed) + 1) % speeds.size]; player.setPlaybackSpeed(speed) }, 12).padding(14.dp), color = Color.White)
                Text("✕ Fechar", Modifier.neon({ panel = false }, 12).padding(14.dp), color = Color.White)
            }
        }

        // ---------- lista de canais (aperte OK no canal ao vivo)
        if (live && overlay) {
            var selCat by remember { mutableStateOf(cur.group) }
            val catList = liveRows.firstOrNull { it.first == selCat }?.second ?: curList
            val ls = rememberLazyListState()
            LaunchedEffect(selCat) { val i = catList.indexOfFirst { it.url == cur.url }; if (i >= 0) ls.scrollToItem(i) }
            Row(
                Modifier.align(Alignment.CenterStart).fillMaxHeight().width(600.dp)
                    .background(Brush.horizontalGradient(listOf(Color(0xF0000000), Color(0xE0000000), Color.Transparent))).padding(16.dp)
            ) {
                LazyColumn(Modifier.width(190.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(liveRows.size) { i ->
                        val g = liveRows[i].first
                        Text(g, Modifier.fillMaxWidth().neon({ selCat = g }, 10).padding(12.dp),
                            color = if (g == selCat) Gold else Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    item {
                        Text("▭ Proporção: ${ratioNames[ratio]}", Modifier.fillMaxWidth()
                            .neon({ ratio = (ratio + 1) % 3; prefs.edit().putInt("ratio", ratio).apply() }, 10).padding(12.dp), color = Color.White, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.width(10.dp))
                LazyColumn(Modifier.weight(1f).fillMaxHeight(), state = ls, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(catList.size) { i ->
                        val c = catList[i]
                        val isCur = c.url == cur.url
                        Row(
                            (if (isCur) Modifier.focusRequester(curFr) else Modifier).fillMaxWidth()
                                .neon({ curList = catList; idx = i; overlay = false }, 10).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${i + 1}", Modifier.width(38.dp), color = Gold, fontWeight = FontWeight.Black, fontSize = 17.sp)
                            Box(Modifier.size(42.dp), Alignment.Center) {
                                if (c.logo != null) AsyncImage(c.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                else Text("▶", color = Gold)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(c.name, color = if (isCur) Gold else Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
