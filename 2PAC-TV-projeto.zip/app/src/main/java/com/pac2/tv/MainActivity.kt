package com.pac2.tv

import android.os.Bundle
import android.os.Process
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.system.exitProcess

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(e.stackTraceToString()) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
            Process.killProcess(Process.myPid()); exitProcess(10)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg)) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var intro by rememberSaveable { mutableStateOf(true) }
    var channels by remember { mutableStateOf(listOf<Channel>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Pair<List<Channel>, Int>?>(null) }
    var crash by remember {
        mutableStateOf(File(ctx.filesDir, "crash.txt").takeIf { it.exists() }?.readText())
    }

    fun load(source: (File) -> Unit) {
        scope.launch {
            loading = true; error = null
            try {
                val list = withContext(Dispatchers.IO) {
                    val tmp = File(ctx.filesDir, "tmp.m3u")
                    source(tmp)
                    val l = tmp.bufferedReader().use { M3uParser.parse(it) }
                    if (l.isNotEmpty()) tmp.copyTo(File(ctx.filesDir, "cache.m3u"), true)
                    tmp.delete()
                    l
                }
                if (list.isEmpty()) error = "Nenhum canal encontrado na lista." else channels = list
            } catch (e: Throwable) { error = "Erro: ${e.message ?: e.javaClass.simpleName}" }
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        try {
            val f = File(ctx.filesDir, "cache.m3u")
            if (f.exists()) channels = withContext(Dispatchers.IO) { f.bufferedReader().use { M3uParser.parse(it) } }
        } catch (e: Throwable) { File(ctx.filesDir, "cache.m3u").delete() }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) load { tmp ->
            ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    val p = playing
    when {
        intro -> IntroScreen { intro = false }
        p != null -> PlayerScreen(p.first, p.second) { playing = null }
        else -> HomeScreen(
            channels, loading, error, prefs.getString("url", "") ?: "",
            onUrl = { u ->
                prefs.edit().putString("url", u).apply()
                load { tmp ->
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", "2PACTV/1.0")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                }
            },
            onFile = { picker.launch(arrayOf("*/*")) },
            onPlay = { l, i -> playing = l to i }
        )
    }

    crash?.let { txt ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Erro anterior (tire um print)") },
            text = { Text(txt.take(1400), fontSize = 10.sp) },
            confirmButton = { TextButton({ File(ctx.filesDir, "crash.txt").delete(); crash = null }) { Text("OK") } }
        )
    }
}
