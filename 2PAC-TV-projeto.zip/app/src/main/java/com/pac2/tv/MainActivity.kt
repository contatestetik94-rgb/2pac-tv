package com.pac2.tv

import android.os.Bundle
import android.os.Process
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.system.exitProcess

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(e.stackTraceToString()) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
            Process.killProcess(Process.myPid()); exitProcess(10)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Bg)) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    // migração: formato padrão dos canais ao vivo passa a ser TS (abre mais rápido)
    remember { if (prefs.getInt("fmtv", 0) < 2) prefs.edit().putString("fmt", "ts").putInt("fmtv", 2).apply(); Unit }
    var intro by rememberSaveable { mutableStateOf(true) }
    var booted by remember { mutableStateOf(false) }
    var allChannels by remember { mutableStateOf(listOf<Channel>()) }
    var hdOnly by remember { mutableStateOf(prefs.getBoolean("hdonly", true)) }
    val channels = remember(allChannels, hdOnly) { if (hdOnly) applyQuality(allChannels) else allChannels }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Triple<List<Channel>, Int, Boolean>?>(null) }
    var layout by remember { mutableIntStateOf(prefs.getInt("layout", 0)) }
    var tab by rememberSaveable { mutableIntStateOf(if (prefs.getInt("layout", 0) == 1) -1 else 1) }
    var seriesShow by remember { mutableStateOf<String?>(null) }
    var seriesEps by remember { mutableStateOf(listOf<Channel>()) }
    var settings by remember { mutableStateOf(false) }
    var showLogin by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var smooth by remember { mutableStateOf(prefs.getBoolean("smooth", false)) }
    var preview by remember { mutableStateOf(prefs.getBoolean("preview", true)) }
    var ratio by remember { mutableIntStateOf(prefs.getInt("ratio", 0)) }
    var hidden by remember { mutableStateOf(prefs.getStringSet("hidden", emptySet())?.toSet() ?: emptySet<String>()) }
    var fmt by remember { mutableStateOf(prefs.getString("fmt", "ts") ?: "ts") }
    var games by remember { mutableStateOf(listOf<Game>()) }
    var gamesLoading by remember { mutableStateOf(false) }
    var gamesAt by remember { mutableLongStateOf(0L) }
    var favs by remember { mutableStateOf(Store.load(prefs, "favs")) }
    var hist by remember { mutableStateOf(Store.load(prefs, "hist")) }
    var crash by remember {
        mutableStateOf(File(ctx.filesDir, "crash.txt").takeIf { it.exists() }?.readText())
    }
    val hasLogin = (prefs.getString("srv", "") ?: "").isNotBlank()
    val liveRows = remember(channels, hidden) { channels.filter { it.type == LIVE && it.group !in hidden }.groupBy { it.group }.toList() }

    fun creds() = Triple(prefs.getString("srv", "") ?: "", prefs.getString("usr", "") ?: "", prefs.getString("pwd", "") ?: "")
    fun toggleFav(c: Channel) {
        favs = if (favs.any { it.url == c.url }) favs.filter { it.url != c.url } else listOf(c) + favs
        Store.save(prefs, "favs", favs, 500)
    }
    fun play(l: List<Channel>, i: Int, live: Boolean) {
        playing = Triple(l, i, live)
        hist = (listOf(l[i]) + hist.filter { it.url != l[i].url }).take(40)
        Store.save(prefs, "hist", hist, 40)
    }

    fun loadM3u(source: (File) -> Unit) {
        scope.launch {
            loading = true; error = null
            try {
                val list = withContext(Dispatchers.IO) {
                    val tmp = File(ctx.filesDir, "tmp.m3u")
                    source(tmp)
                    val l = tmp.bufferedReader().use { M3uParser.parse(it) }
                    if (l.isNotEmpty()) tmp.copyTo(File(ctx.filesDir, "cache.m3u"), true)
                    tmp.delete()
                    l
                }
                if (list.isEmpty()) error = "Nenhum canal encontrado na lista." else { allChannels = list; showLogin = false; settings = false }
            } catch (e: Throwable) { error = "Erro: ${e.message ?: e.javaClass.simpleName}" }
            loading = false
        }
    }

    fun login(srv: String, u: String, p: String) {
        scope.launch {
            loading = true; error = null
            try {
                val x = Xtream(srv, u.trim(), p.trim())
                val (list, exp) = withContext(Dispatchers.IO) {
                    val e = x.check()
                    val l = x.load()
                    if (l.isEmpty()) throw Exception("Nenhum conteúdo encontrado")
                    saveCache(l, File(ctx.filesDir, "cache.m3u"))
                    l to e
                }
                prefs.edit().putString("srv", srv.trim()).putString("usr", u.trim()).putString("pwd", p.trim()).putString("exp", exp).apply()
                Session.x = x
                allChannels = list; showLogin = false; settings = false; gamesAt = 0L
            } catch (e: Throwable) { error = "Erro: ${e.message ?: e.javaClass.simpleName}" }
            loading = false
        }
    }

    fun openSeries(rep: Channel) {
        val show = rep.show ?: rep.name
        if (rep.url.startsWith("series:")) {
            scope.launch {
                loading = true; error = null
                try {
                    val (s, u, p) = creds()
                    val eps = withContext(Dispatchers.IO) { Xtream(s, u, p).episodes(rep.url.removePrefix("series:"), show) }
                    if (eps.isEmpty()) error = "Esta série não tem episódios." else { seriesEps = eps; seriesShow = show }
                } catch (e: Throwable) { error = "Erro: ${e.message ?: e.javaClass.simpleName}" }
                loading = false
            }
        } else {
            seriesEps = channels.filter { it.type == SERIES && it.show == show }
            seriesShow = show
        }
    }

    fun loadGames() {
        if (!hasLogin || gamesLoading || System.currentTimeMillis() - gamesAt < 600000L) return
        scope.launch {
            gamesLoading = true
            try {
                val (s, u, p) = creds()
                games = withContext(Dispatchers.IO) { Xtream(s, u, p).sportsEvents(channels) }
                gamesAt = System.currentTimeMillis()
            } catch (e: Throwable) {}
            gamesLoading = false
        }
    }

    LaunchedEffect(Unit) {
        try {
            val (s, u, p) = creds()
            if (s.isNotBlank()) Session.x = Xtream(s, u, p)
            val f = File(ctx.filesDir, "cache.m3u")
            if (f.exists()) allChannels = withContext(Dispatchers.IO) { f.bufferedReader().use { M3uParser.parse(it) } }
        } catch (e: Throwable) { File(ctx.filesDir, "cache.m3u").delete() }
        booted = true
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadM3u { tmp ->
            ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    val p = playing
    val sh = seriesShow
    when {
        intro -> IntroScreen { intro = false }
        !booted -> Box(Modifier.fillMaxSize().background(Color.Black))
        p != null -> PlayerScreen(p.first, p.second, p.third, liveRows, favs, { toggleFav(it) }) { playing = null }
        settings -> {
            val groups = remember(channels) { channels.map { it.group }.distinct().sorted() }
            val srv = prefs.getString("srv", "") ?: ""
            val exp = prefs.getString("exp", "")?.toLongOrNull()?.let { java.text.SimpleDateFormat("dd/MM/yyyy").format(java.util.Date(it * 1000)) }
            SettingsScreen(
                host = srv.substringAfter("://").substringBefore("/"),
                status = if (srv.isNotBlank()) "Ativa" + (exp?.let { " · vence $it" } ?: "") else "Lista M3U",
                fmt = fmt, hasLogin = srv.isNotBlank(), groups = groups, hidden = hidden,
                onHidden = { hidden = it; prefs.edit().putStringSet("hidden", it).apply() },
                onFmt = { fmt = it; prefs.edit().putString("fmt", it).apply() },
                onPlaylist = { settings = false; showLogin = true },
                onRefresh = { val (s, u, pw) = creds(); login(s, u, pw) },
                onClear = { ctx.cacheDir.deleteRecursively(); Toast.makeText(ctx, "Armazenamento limpo", Toast.LENGTH_SHORT).show() },
                onLogout = {
                    prefs.edit().remove("srv").remove("usr").remove("pwd").remove("exp").apply()
                    File(ctx.filesDir, "cache.m3u").delete(); Session.x = null
                    allChannels = emptyList(); settings = false; showLogin = false
                },
                onBack = { settings = false },
                smooth = smooth, onSmooth = { smooth = it; prefs.edit().putBoolean("smooth", it).apply() },
                ratio = ratio, onRatio = { ratio = it; prefs.edit().putInt("ratio", it).apply() },
                layout = layout, onLayout = { layout = it; prefs.edit().putInt("layout", it).apply(); tab = if (it == 1) -1 else 1 },
                hdOnly = hdOnly, onHdOnly = { hdOnly = it; prefs.edit().putBoolean("hdonly", it).apply() },
                preview = preview, onPreview = { preview = it; prefs.edit().putBoolean("preview", it).apply() }
            )
        }
        sh != null -> SeriesScreen(sh, seriesEps, { l, i -> play(l, i, false) }) { seriesShow = null }
        searching -> SearchScreen(channels, hidden, { l, i, live -> play(l, i, live) }, { openSeries(it) }) { searching = false }
        channels.isEmpty() || showLogin -> LoginScreen(
            prefs.getString("srv", "") ?: "", prefs.getString("usr", "") ?: "", prefs.getString("pwd", "") ?: "",
            loading, error, onLogin = { s, u, pw -> login(s, u, pw) },
            onM3u = { u ->
                loadM3u { tmp ->
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 GAELTV")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                }
            },
            onFile = { picker.launch(arrayOf("*/*")) },
            onBack = if (channels.isNotEmpty()) ({ showLogin = false }) else null
        )
        else -> HomeScreen(
            channels, loading, error, tab, { tab = it }, hidden, layout,
            daysLeft = prefs.getString("exp", "")?.toLongOrNull()?.let { ((it * 1000 - System.currentTimeMillis()) / 86400000L).toInt().coerceAtLeast(0) },
            games = games, gamesLoading = gamesLoading, hasLogin = hasLogin, onLoadGames = { loadGames() },
            favs = favs, hist = hist, onFav = { toggleFav(it) }, preview = preview,
            onPlay = { l, i, live -> play(l, i, live) },
            onSeries = { openSeries(it) },
            onSettings = { settings = true },
            onSearch = { searching = true },
            onExit = { (ctx as? android.app.Activity)?.finish() }
        )
    }

    crash?.let { txt ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Erro anterior (tire um print)") },
            text = { Text(txt.take(1400), fontSize = 10.sp) },
            confirmButton = { TextButton({ File(ctx.filesDir, "crash.txt").delete(); crash = null }) { Text("OK") } }
        )
    }
}
