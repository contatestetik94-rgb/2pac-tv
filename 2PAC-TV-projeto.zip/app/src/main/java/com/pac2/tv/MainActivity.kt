package com.pac2.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg)) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var intro by rememberSaveable { mutableStateOf(true) }
    var channels by remember { mutableStateOf(listOf<Channel>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Pair<List<Channel>, Int>?>(null) }

    fun load(block: suspend () -> String) {
        scope.launch {
            loading = true; error = null
            try {
                val text = withContext(Dispatchers.IO) { block() }
                val list = M3uParser.parse(text)
                if (list.isEmpty()) error = "Nenhum canal encontrado na lista."
                else { channels = list; withContext(Dispatchers.IO) { File(ctx.filesDir, "cache.m3u").writeText(text) } }
            } catch (e: Exception) { error = "Erro: ${e.message}" }
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        val f = File(ctx.filesDir, "cache.m3u")
        if (f.exists()) channels = withContext(Dispatchers.IO) { M3uParser.parse(f.readText()) }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) load { ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() } }
    }

    val p = playing
    when {
        intro -> IntroScreen { intro = false }
        p != null -> PlayerScreen(p.first, p.second) { playing = null }
        else -> HomeScreen(
            channels, loading, error, prefs.getString("url", "") ?: "",
            onUrl = { u ->
                prefs.edit().putString("url", u).apply()
                load {
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", "2PACTV/1.0")
                    c.inputStream.bufferedReader().use { it.readText() }
                }
            },
            onFile = { picker.launch(arrayOf("*/*")) },
            onPlay = { l, i -> playing = l to i }
        )
    }
}
