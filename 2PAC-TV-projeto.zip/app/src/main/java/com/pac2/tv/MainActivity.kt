package com.pac2.tv

import android.os.Bundle
import android.os.Process
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.system.exitProcess

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(e.stackTraceToString()) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
            Process.killProcess(Process.myPid()); exitProcess(10)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Bg)) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var intro by rememberSaveable { mutableStateOf(true) }
    var booted by remember { mutableStateOf(false) }
    var channels by remember { mutableStateOf(listOf<Channel>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Triple<List<Channel>, Int, Boolean>?>(null) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var seriesShow by remember { mutableStateOf<String?>(null) }
    var seriesEps by remember { mutableStateOf(listOf<Channel>()) }
    var settings by remember { mutableStateOf(false) }
    var showLogin by remember { mutableStateOf(false) }
    var hidden by remember { mutableStateOf(prefs.getStringSet("hidden", emptySet())?.toSet() ?: emptySet<String>()) }
    remember { if (prefs.getInt("uiv", 0) < 2) prefs.edit().putInt("ui", 3).putInt("uiv", 2).apply(); Unit }
    var searching by remember { mutableStateOf(false) }
    var smooth by remember { mutableStateOf(prefs.getBoolean("smooth", false)) }
    var ratio by remember { mutableIntStateOf(prefs.getInt("ratio", 0)) }
    var uiStyle by remember { mutableStateOf(prefs.getInt("ui", 0)) }
    var pickUi by remember { mutableStateOf(!prefs.getBoolean("uiChosen", false)) }
    var fmt by remember { mutableStateOf(prefs.getString("fmt", "m3u8") ?: "m3u8") }
    var crash by remember {
        mutableStateOf(File(ctx.filesDir, "crash.txt").takeIf { it.exists() }?.readText())
    }

    fun loadM3u(source: (File) -> Unit) {
        scope.launch {
            loading = true; error = null
            try {
                val list = withContext(Dispatchers.IO) {
                    val tmp = File(ctx.filesDir, "tmp.m3u")
                    source(tmp)
                    val l = tmp.bufferedReader().use { M3uParser.parse(it) }
                    if (l.isNotEmpty()) tmp.copyTo(File(ctx.filesDir, "cache.m3u"), true)
                    tmp.delete()
                    l
                }
                if (list.isEmpty()) error = "Nenhum canal encontrado na lista." else { channels = list; showLogin = false; settings = false }
            } catch (e: Throwable) { error = "Erro: ${e.message ?: e.javaClass.simpleName}" }
            loading = false
        }
    }

    fun login(srv: String, u: String, p: String) {
        scope.launch {
            loading = true; error = null
            try {
                val x = Xtream(srv, u.trim(), p.trim())
                val (list, exp) = withContext(Dispatchers.IO) {
                    val e = x.check()
                    val l = x.load()
                    if (l.isEmpty()) throw Exception("Nenhum conteúdo encontrado")
                    saveCache(l, File(ctx.filesDir, "cache.m3u"))
                    l to e
                }
                prefs.edit().putString("srv", srv.trim()).putString("usr", u.trim()).putString("pwd", p.trim()).putString("exp", exp).apply()
                channels = list; showLogin = false; settings = false
            } catch (e: Throwable) { error = "Erro: ${e.message ?: e.javaClass.simpleName}" }
            loading = false
        }
    }

    fun openSeries(rep: Channel) {
        val show = rep.show ?: rep.name
        if (rep.url.startsWith("series:")) {
            scope.launch {
                loading = true; error = null
                try {
                    val eps = withContext(Dispatchers.IO) {
                        Xtream(prefs.getString("srv", "") ?: "", prefs.getString("usr", "") ?: "", prefs.getString("pwd", "") ?: "")
                            .episodes(rep.url.removePrefix("series:"), show)
                    }
                    if (eps.isEmpty()) error = "Esta série não tem episódios." else { seriesEps = eps; seriesShow = show }
                } catch (e: Throwable) { error = "Erro: ${e.message ?: e.javaClass.simpleName}" }
                loading = false
            }
        } else {
            seriesEps = channels.filter { it.type == SERIES && it.show == show }
            seriesShow = show
        }
    }

    LaunchedEffect(Unit) {
        try {
            val f = File(ctx.filesDir, "cache.m3u")
            if (f.exists()) channels = withContext(Dispatchers.IO) { f.bufferedReader().use { M3uParser.parse(it) } }
        } catch (e: Throwable) { File(ctx.filesDir, "cache.m3u").delete() }
        booted = true
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadM3u { tmp ->
            ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    val p = playing
    val sh = seriesShow
    when {
        intro -> IntroScreen { intro = false }
        !booted -> Box(Modifier.fillMaxSize().background(Color.Black))
        pickUi -> {
            val chosen = prefs.getBoolean("uiChosen", false)
            UiStyleScreen(uiStyle, !chosen, { uiStyle = it },
                { prefs.edit().putInt("ui", uiStyle).putBoolean("uiChosen", true).apply(); pickUi = false },
                if (chosen) ({ uiStyle = prefs.getInt("ui", 0); pickUi = false }) else null)
        }
        p != null -> PlayerScreen(p.first, p.second, p.third) { playing = null }
        settings -> {
            val groups = remember(channels) { channels.map { it.group }.distinct().sorted() }
            val srv = prefs.getString("srv", "") ?: ""
            val exp = prefs.getString("exp", "")?.toLongOrNull()?.let { java.text.SimpleDateFormat("dd/MM/yyyy").format(java.util.Date(it * 1000)) }
            SettingsScreen(
                host = srv.substringAfter("://").substringBefore("/"),
                status = if (srv.isNotBlank()) "Ativa" + (exp?.let { " · vence $it" } ?: "") else "Lista M3U",
                fmt = fmt, hasLogin = srv.isNotBlank(), groups = groups, hidden = hidden,
                onHidden = { hidden = it; prefs.edit().putStringSet("hidden", it).apply() },
                onFmt = { fmt = it; prefs.edit().putString("fmt", it).apply() },
                onPlaylist = { settings = false; showLogin = true },
                onRefresh = { login(srv, prefs.getString("usr", "") ?: "", prefs.getString("pwd", "") ?: "") },
                onClear = { ctx.cacheDir.deleteRecursively(); Toast.makeText(ctx, "Armazenamento limpo", Toast.LENGTH_SHORT).show() },
                onLogout = {
                    prefs.edit().remove("srv").remove("usr").remove("pwd").remove("exp").apply()
                    File(ctx.filesDir, "cache.m3u").delete(); channels = emptyList(); settings = false; showLogin = false
                },
                onBack = { settings = false },
                uiName = listOf("Moderna", "Futuro", "Simples", "Cinema")[uiStyle],
                onUi = { settings = false; pickUi = true },
                smooth = smooth, onSmooth = { smooth = it; prefs.edit().putBoolean("smooth", it).apply() },
                ratio = ratio, onRatio = { ratio = it; prefs.edit().putInt("ratio", it).apply() }
            )
        }
        sh != null -> SeriesScreen(sh, seriesEps, { l, i -> playing = Triple(l, i, false) }) { seriesShow = null }
        searching -> SearchScreen(channels, hidden, { l, i, live -> playing = Triple(l, i, live) }, { openSeries(it) }) { searching = false }
        channels.isEmpty() || showLogin -> LoginScreen(
            prefs.getString("srv", "") ?: "", prefs.getString("usr", "") ?: "", prefs.getString("pwd", "") ?: "",
            loading, error, onLogin = { s, u, pw -> login(s, u, pw) },
            onM3u = { u ->
                loadM3u { tmp ->
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 GAELTV")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                }
            },
            onFile = { picker.launch(arrayOf("*/*")) },
            onBack = if (channels.isNotEmpty()) ({ showLogin = false }) else null
        )
        else -> HomeScreen(
            channels, loading, error, tab, { tab = it }, hidden, uiStyle,
            onPlay = { l, i, live -> playing = Triple(l, i, live) },
            onSeries = { openSeries(it) },
            onSettings = { settings = true },
            daysLeft = prefs.getString("exp", "")?.toLongOrNull()?.let { ((it * 1000 - System.currentTimeMillis()) / 86400000L).toInt().coerceAtLeast(0) },
            onSearch = { searching = true }
        )
    }

    crash?.let { txt ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Erro anterior (tire um print)") },
            text = { Text(txt.take(1400), fontSize = 10.sp) },
            confirmButton = { TextButton({ File(ctx.filesDir, "crash.txt").delete(); crash = null }) { Text("OK") } }
        )
    }
}
