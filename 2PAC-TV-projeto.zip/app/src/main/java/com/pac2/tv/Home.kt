package com.pac2.tv

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

fun cleanCat(s: String) =
    s.replace(Regex("^\\s*(filmes?|s[eé]ries?|movies?|series)\\s*[|:\\-–—/]*\\s*", RegexOption.IGNORE_CASE), "").ifBlank { s }

/** Letras em 3D: várias cópias deslocadas formam a "profundidade". */
@Composable
fun Text3D(text: String, front: Color, side: Color, size: TextUnit) {
    Box(Modifier.padding(end = 6.dp, bottom = 6.dp)) {
        for (i in 4 downTo 1) Text(text, Modifier.offset(x = (i * 0.8f).dp, y = (i * 1.1f).dp), color = side, fontSize = size, fontWeight = FontWeight.Black)
        Text(text, color = front, fontSize = size, fontWeight = FontWeight.Black,
            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.5f), Offset(2f, 3f), 4f)))
    }
}

/** Capa do título. Se vier sem imagem (ou falhar), pede ao painel; se ainda não houver, desenha uma capa com o nome. */
@Composable
fun PosterArt(c: Channel, modifier: Modifier, crop: Boolean = true) {
    var url by remember(c.url) { mutableStateOf(c.logo) }
    var failed by remember(c.url) { mutableStateOf(false) }
    LaunchedEffect(c.url, failed) {
        if ((url == null || failed) && c.type != LIVE) {
            val u = Covers.get(c)
            if (u != null && u != url) { url = u; failed = false }
        }
    }
    Box(modifier, Alignment.Center) {
        val u = url
        if (u != null && !failed) AsyncImage(u, null, Modifier.fillMaxSize(),
            contentScale = if (crop) ContentScale.Crop else ContentScale.Fit, onError = { failed = true })
        else Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16307A), Color(0xFF0A1030)))), Alignment.Center) {
            Text(c.name, Modifier.padding(8.dp), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 5, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun Poster(c: Channel, poster: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(if (poster) 130.dp else 160.dp).neon(onClick)) {
        PosterArt(c, Modifier.fillMaxWidth().height(if (poster) 190.dp else 90.dp), poster)
        Text(c.name, Modifier.padding(8.dp), color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun PosterCard(c: Channel, onFocus: () -> Unit, onLong: () -> Unit, onClick: () -> Unit) {
    Column(Modifier.width(118.dp)) {
        PosterArt(c, Modifier.fillMaxWidth().height(170.dp).neon(onClick, 10, onFocus, onLong))
        Text(c.name, Modifier.padding(top = 6.dp), color = Color.White, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun HeroPanel(c: Channel, isFav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    val bg = Color(0xFF0B1030)
    val kind = if (c.type == SERIES) "SÉRIE" else if (c.type == MOVIE) "FILME" else "AO VIVO"
    Box(Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(16.dp)).background(bg)) {
        PosterArt(c, Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(0.5f))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(bg, bg.copy(alpha = 0.92f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(22.dp).fillMaxWidth(0.58f)) {
            Text(c.name, color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text(kind, Modifier.background(Color(0x33FFFFFF), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp), color = Color.White, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Text("Categoria: ${cleanCat(c.group)}", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("▶  Assistir", Modifier.neon(onClick, 8).background(Gold).padding(horizontal = 24.dp, vertical = 10.dp),
                    color = Color(0xFF1A1200), fontWeight = FontWeight.Bold)
                Text(if (isFav) "♥ Favorito" else "♡ Favoritar", Modifier.neon(onFav, 8).padding(horizontal = 16.dp, vertical = 10.dp),
                    color = if (isFav) Color(0xFFFF4D6D) else Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun GenreChips(cats: List<String>, sel: String?, onSel: (String?) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
        item {
            Text("Todos", Modifier.neon({ onSel(null) }, 18).padding(horizontal = 14.dp, vertical = 6.dp),
                color = if (sel == null) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        items(cats.size) { i ->
            val g = cats[i]
            Text(cleanCat(g), Modifier.neon({ onSel(g) }, 18).padding(horizontal = 14.dp, vertical = 6.dp),
                color = if (g == sel) Gold else Color.White, fontSize = 13.sp, maxLines = 1)
        }
    }
}

/** Programa que está no ar agora (guia de programação). */
@Composable
fun EpgNow(ch: Channel) {
    val tf = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    var progs by remember(ch.url) { mutableStateOf<List<Program>?>(null) }
    LaunchedEffect(ch.url) { progs = Epg.get(ch) }
    val now = System.currentTimeMillis()
    val p = progs
    val cur = p?.firstOrNull { it.start <= now && it.end > now } ?: p?.firstOrNull { it.end > now }
    val txt = if (cur != null) "${tf.format(java.util.Date(cur.start))}–${tf.format(java.util.Date(cur.end))}  ${cur.title}"
              else if (p == null) "…" else "Sem programação"
    Text(txt, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

@Composable
fun ChannelPreview(ch: Channel?, modifier: Modifier) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val player = remember {
        ExoPlayer.Builder(ctx)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(3000, 8000, 800, 1500).build())
            .build().apply { volume = 0f }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(ch?.url) {
        if (ch != null) {
            delay(900)
            player.setMediaItem(MediaItem.fromUri(liveUrl(ch.url, prefs.getString("fmt", "ts"))))
            player.prepare(); player.playWhenReady = true
        }
    }
    AndroidView(modifier = modifier, factory = { c ->
        PlayerView(c).apply { this.player = player; useController = false; isFocusable = false; resizeMode = 0 }
    })
}

@Composable
fun PreviewPanel(ch: Channel?, modifier: Modifier) {
    val tf = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    var progs by remember(ch?.url) { mutableStateOf<List<Program>>(emptyList()) }
    LaunchedEffect(ch?.url) { if (ch != null) progs = Epg.get(ch) }
    val now = System.currentTimeMillis()
    val upcoming = progs.filter { it.end > now }.take(5)
    Column(modifier) {
        ChannelPreview(ch, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp)).background(Color.Black))
        Spacer(Modifier.height(8.dp))
        Text(ch?.name ?: "", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("Guia de programação", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        if (upcoming.isEmpty()) Text("Sem programação disponível.", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
        else upcoming.forEach { p ->
            val on = p.start <= now
            Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                Text(tf.format(java.util.Date(p.start)), Modifier.width(52.dp), color = if (on) Gold else Color.White.copy(alpha = 0.7f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(p.title, Modifier.weight(1f), color = if (on) Color.White else Color.White.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun LiveGuide(rows: List<Pair<String, List<Channel>>>, favs: List<Channel>, onFav: (Channel) -> Unit, preview: Boolean, onPlay: (List<Channel>, Int) -> Unit) {
    var selCat by remember { mutableStateOf<String?>(null) }
    val sel = rows.firstOrNull { it.first == selCat } ?: rows.first()
    var focused by remember { mutableStateOf<Channel?>(null) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val boxW = maxWidth
        val wide = boxW > 700.dp
        Row(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.width(190.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(rows.size) { i ->
                    val g = rows[i].first
                    Text(g, Modifier.fillMaxWidth().neon({ selCat = g }, 10).padding(12.dp),
                        color = if (g == sel.first) Gold else Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.width(12.dp))
            LazyColumn(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(sel.second.size) { i ->
                    val c = sel.second[i]
                    val fav = favs.any { it.url == c.url }
                    Row(Modifier.fillMaxWidth().neon({ onPlay(sel.second, i) }, 10, { focused = c }).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", Modifier.width(40.dp), color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Box(Modifier.size(44.dp), Alignment.Center) {
                            if (c.logo != null) AsyncImage(c.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                            else Text("▶", color = Gold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            EpgNow(c)
                        }
                        Text(if (fav) "♥" else "♡", Modifier.neon({ onFav(c) }, 20).padding(horizontal = 10.dp, vertical = 6.dp),
                            color = if (fav) Color(0xFFFF4D6D) else Color.White, fontSize = 16.sp)
                    }
                }
            }
            if (wide && preview) {
                Spacer(Modifier.width(12.dp))
                PreviewPanel(focused ?: sel.second.firstOrNull(), Modifier.width(boxW * 0.36f))
            }
        }
    }
}

@Composable
fun GamesPanel(games: List<Game>, loading: Boolean, hasLogin: Boolean, onPlay: (Game) -> Unit) {
    var day by remember { mutableIntStateOf(0) }
    val tf = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    val now = System.currentTimeMillis()
    val cal = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }
    val d0 = cal.timeInMillis + day * 86400000L
    val shown = games.filter { (it.start >= d0 && it.start < d0 + 86400000L) || (day == 0 && it.start < now && it.end > now) }
    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("HOJE", "AMANHÃ").forEachIndexed { i, l ->
                Text(l, Modifier.neon({ day = i }, 10).padding(horizontal = 18.dp, vertical = 8.dp), color = if (i == day) Gold else Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Text("JOGOS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text("${shown.size}", Modifier.background(Color(0xFFD33A3A), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 2.dp), color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
            !hasLogin -> Text("Os jogos do dia usam a programação (EPG) do seu painel. Entre com usuário e senha para ver.", color = Color.White.copy(alpha = 0.7f))
            shown.isEmpty() -> Text("Nenhum jogo encontrado na programação do seu painel para este dia.", color = Color.White.copy(alpha = 0.7f))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown.size) { i ->
                    val g = shown[i]
                    val liveNow = g.start <= now && g.end > now
                    Row(Modifier.fillMaxWidth().neon({ onPlay(g) }, 14).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp), Alignment.Center) {
                            if (g.channel.logo != null) AsyncImage(g.channel.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                            else Text("▶", color = Gold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.width(84.dp)) {
                            Text(tf.format(java.util.Date(g.start)), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text(g.channel.name, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(g.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (g.info.isNotBlank()) Text(g.info, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(if (liveNow) "AO VIVO" else "Agendado",
                            Modifier.background(if (liveNow) Color(0xFFD33A3A) else Color(0xFF3B5BDB), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ClockText() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(20000) } }
    val d = java.util.Date(now)
    val loc = java.util.Locale("pt", "BR")
    Column(horizontalAlignment = Alignment.End) {
        Text(java.text.SimpleDateFormat("HH:mm", loc).format(d), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(java.text.SimpleDateFormat("EEE, dd MMM", loc).format(d).replaceFirstChar { it.uppercase() }, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

/** Layout 2: painel "Início" com banner e atalhos grandes. */
@Composable
fun Dashboard(onTab: (Int) -> Unit) {
    val tiles = listOf(Triple("📺", "TV AO VIVO", 0), Triple("🍿", "FILMES", 1), Triple("🎬", "SÉRIES", 2),
        Triple("🧒", "INFANTIL", 4), Triple("⚽", "ESPORTES", 3), Triple("⭐", "FAVORITOS", 5))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF040A22)), Alignment.Center) {
            Image(painterResource(R.drawable.logo_banner), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
        Text("SUA TV SEM LIMITES", Modifier.fillMaxWidth(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp,
            letterSpacing = 4.sp, textAlign = TextAlign.Center)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(4.dp)) {
            items(tiles.size) { i ->
                val (emoji, label, id) = tiles[i]
                Column(Modifier.width(140.dp).height(150.dp).neon({ onTab(id) }, 16)
                    .background(Brush.verticalGradient(listOf(Color(0xFF123A9A), Color(0xFF071445)))),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(emoji, fontSize = 46.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0x33000000), RoundedCornerShape(14.dp)).horizontalScroll(rememberScrollState()).padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🚀 Alta Qualidade", color = Color.White, fontSize = 14.sp)
            Text("⚡ Canais Estáveis", color = Color.White, fontSize = 14.sp)
            Text("🎧 Suporte 24h", color = Color.White, fontSize = 14.sp)
            Text("A melhor experiência IPTV!", color = NeonBlueHi, fontSize = 14.sp, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold)
        }
    }
}

/** Tela inicial. tab: -1 Início, 0 TV, 1 Filmes, 2 Séries, 3 Jogos, 4 Infantil, 5 Favoritos, 6 Histórico. layout: 0 menu lateral com banner, 1 painel Início. */
@Composable
fun HomeScreen(
    channels: List<Channel>, loading: Boolean, error: String?, tab: Int, onTab: (Int) -> Unit, hidden: Set<String>, layout: Int,
    daysLeft: Int?, games: List<Game>, gamesLoading: Boolean, hasLogin: Boolean, onLoadGames: () -> Unit,
    favs: List<Channel>, hist: List<Channel>, onFav: (Channel) -> Unit, preview: Boolean,
    onPlay: (List<Channel>, Int, Boolean) -> Unit, onSeries: (Channel) -> Unit, onSettings: () -> Unit, onSearch: () -> Unit, onExit: () -> Unit
) {
    val t = if (layout == 0 && tab < 0) 1 else tab
    var cat by remember(t) { mutableStateOf<String?>(null) }
    val live = remember(channels) { channels.filter { it.type == LIVE } }
    val movies = remember(channels) { channels.filter { it.type == MOVIE } }
    val shows = remember(channels) { channels.filter { it.type == SERIES }.distinctBy { it.show } }
    val kids = remember(movies, shows) {
        (movies + shows).filter { c -> listOf("infantil", "kids", "desenho", "crian", "cartoon").any { c.group.contains(it, true) } }
    }
    val base0 = when (t) { 0 -> live; 1 -> movies; 2 -> shows; 4 -> kids; 5 -> favs; 6 -> hist; else -> emptyList<Channel>() }
    val rows = remember(base0, hidden, t) {
        val f = base0.filter { it.group !in hidden }
        if (t == 5 || t == 6) f.groupBy { if (it.type == LIVE) "Canais" else if (it.type == MOVIE) "Filmes" else "Séries" }.toList()
        else f.groupBy { it.group }.toList()
    }
    val featured = remember(rows) { rows.randomOrNull()?.second?.filter { it.logo != null }?.randomOrNull() }
    var heroItem by remember(rows) { mutableStateOf(featured) }
    LaunchedEffect(t) { if (t == 3) onLoadGames() }
    val click: (List<Channel>, Int) -> Unit = { l, i ->
        val c = l[i]
        if (c.type == SERIES && (c.url.startsWith("series:") || t == 2 || t == 4)) onSeries(c) else onPlay(l, i, c.type == LIVE)
    }
    val tabLabels = listOf("TV", "FILMES", "SÉRIES", "JOGOS", "INFANTIL", "FAVORITOS", "HISTÓRICO")

    val pill: @Composable () -> Unit = {
        if (daysLeft != null) Text("$daysLeft dias restantes", Modifier.background(Color(0x44FFC21A), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
            color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
    val content: @Composable () -> Unit = {
        if (error != null) Text(error, color = Color(0xFFFF6B6B))
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
            t == 3 -> GamesPanel(games, gamesLoading, hasLogin) { g -> onPlay(listOf(g.channel), 0, true) }
            rows.isEmpty() -> Text(
                if (t == 5) "Nenhum favorito ainda. Segure o botão OK sobre um título (ou use ♡) para favoritar."
                else if (t == 6) "Você ainda não assistiu nada." else "Nada encontrado nesta aba.",
                color = Color.White.copy(alpha = 0.7f))
            t == 0 -> LiveGuide(rows, favs, onFav, preview) { l, i -> onPlay(l, i, true) }
            else -> {
                val cats = remember(rows) { rows.map { it.first } }
                val sel = cat
                val shelf = t == 1 || t == 2 || t == 4
                if (sel == null) LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (shelf) {
                        item { heroItem?.let { h -> HeroPanel(h, favs.any { it.url == h.url }, { onFav(h) }) { click(listOf(h), 0) } } }
                        item { GenreChips(cats, null) { cat = it } }
                    }
                    items(rows) { (g, list) ->
                        Text(cleanCat(g), Modifier.padding(bottom = 6.dp), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(4.dp)) {
                            items(list.size) { i -> PosterCard(list[i], { heroItem = list[i] }, { onFav(list[i]) }) { click(list, i) } }
                        }
                    }
                } else Column {
                    GenreChips(cats, sel) { cat = it }
                    Spacer(Modifier.height(8.dp))
                    val list = rows.firstOrNull { it.first == sel }?.second ?: emptyList()
                    LazyVerticalGrid(GridCells.Adaptive(118.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(list.size) { i -> PosterCard(list[i], {}, { onFav(list[i]) }) { click(list, i) } }
                    }
                }
            }
        }
    }

    if (layout == 0) Row(Modifier.fillMaxSize().background(bgBrush)) {
        Column(
            Modifier.fillMaxHeight().width(64.dp).background(Color(0x33000000)).padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("🔍", Modifier.neon(onSearch, 12).padding(10.dp), fontSize = 20.sp)
            listOf(0 to "📺", 1 to "🎬", 2 to "📚", 3 to "⚽", 5 to "⭐").forEach { (id, ic) ->
                Text(ic, Modifier.alpha(if (id == t) 1f else 0.55f).neon({ onTab(id) }, 12).padding(10.dp), fontSize = 20.sp)
            }
            Spacer(Modifier.weight(1f))
            Text("⚙", Modifier.neon(onSettings, 12).padding(10.dp), fontSize = 20.sp)
            Image(painterResource(R.drawable.ic_fg), null, Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF0A1A4A)))
        }
        Column(Modifier.weight(1f).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    tabLabels.forEachIndexed { i, l ->
                        val sel = i == t
                        Box(Modifier.neon({ onTab(i) }, 14).padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text3D(l, if (sel) GoldHi else Color(0xFFD6E4FF), if (sel) Color(0xFF8A5A00) else Color(0xFF1A2E7A), 17.sp)
                        }
                    }
                }
                pill()
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    } else Row(Modifier.fillMaxSize().background(bgBrush)) {
        Column(
            Modifier.fillMaxHeight().width(200.dp).background(Color(0x55000000)).verticalScroll(rememberScrollState()).padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Image(painterResource(R.drawable.logo_banner), null, Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.height(4.dp))
            listOf(-1 to "🏠  Início", 0 to "📺  TV ao Vivo", 1 to "🍿  Filmes", 2 to "🎬  Séries", 4 to "🧒  Infantil", 3 to "⚽  Esportes", 5 to "⭐  Favoritos", 6 to "🕘  Histórico").forEach { (id, label) ->
                Text(label, Modifier.fillMaxWidth().neon({ onTab(id) }, 12).padding(12.dp),
                    color = if (id == tab) Gold else Color.White, fontSize = 15.sp, fontWeight = if (id == tab) FontWeight.Bold else FontWeight.Normal)
            }
            Text("↩  Sair", Modifier.fillMaxWidth().neon(onExit, 12).padding(12.dp), color = Color.White, fontSize = 15.sp)
        }
        Column(Modifier.weight(1f).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    Text3D(if (tab == -1) "INÍCIO" else tabLabels[t], GoldHi, Color(0xFF8A5A00), 20.sp)
                }
                Text("🔍", Modifier.neon(onSearch, 12).padding(10.dp), fontSize = 18.sp)
                Spacer(Modifier.width(6.dp))
                Text("⚙", Modifier.neon(onSettings, 12).padding(10.dp), fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                pill()
                Spacer(Modifier.width(12.dp))
                ClockText()
            }
            Spacer(Modifier.height(8.dp))
            if (tab == -1) Dashboard(onTab) else content()
        }
    }
}
