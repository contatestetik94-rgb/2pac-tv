package com.pac2.tv

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

fun cleanCat(s: String) =
    s.replace(Regex("^\\s*(filmes?|s[eé]ries?|movies?|series)\\s*[|:\\-–—/]*\\s*", RegexOption.IGNORE_CASE), "").ifBlank { s }

/** Letras em 3D: várias cópias deslocadas formam a "profundidade". */
@Composable
fun Text3D(text: String, front: Color, side: Color, size: TextUnit) {
    Box(Modifier.padding(end = 6.dp, bottom = 6.dp)) {
        for (i in 4 downTo 1) Text(text, Modifier.offset(x = (i * 0.8f).dp, y = (i * 1.1f).dp), color = side, fontSize = size, fontWeight = FontWeight.Black)
        Text(text, color = front, fontSize = size, fontWeight = FontWeight.Black,
            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.5f), Offset(2f, 3f), 4f)))
    }
}

@Composable
fun PosterCard(c: Channel, onFocus: () -> Unit, onClick: () -> Unit) {
    Column(Modifier.width(118.dp)) {
        Box(Modifier.fillMaxWidth().height(170.dp).neon(onClick, 10, onFocus), Alignment.Center) {
            if (c.logo != null) AsyncImage(c.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Text(c.name.take(1).uppercase(), color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
        }
        Text(c.name, Modifier.padding(top = 6.dp), color = Color.White, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun HeroPanel(c: Channel, onClick: () -> Unit) {
    val bg = Color(0xFF0B1030)
    val kind = if (c.type == SERIES) "SÉRIE" else if (c.type == MOVIE) "FILME" else "AO VIVO"
    Box(Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(16.dp)).background(bg)) {
        if (c.logo != null) AsyncImage(c.logo, null, Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(0.5f), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(bg, bg.copy(alpha = 0.92f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(22.dp).fillMaxWidth(0.55f)) {
            Text(c.name, color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text(kind, Modifier.background(Color(0x33FFFFFF), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp), color = Color.White, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Text("Categoria: ${cleanCat(c.group)}", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))
            Text("▶  Assistir", Modifier.neon(onClick, 8).background(Gold).padding(horizontal = 28.dp, vertical = 10.dp),
                color = Color(0xFF1A1200), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun GenreChips(cats: List<String>, sel: String?, onSel: (String?) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
        item {
            Text("Todos", Modifier.neon({ onSel(null) }, 18).padding(horizontal = 14.dp, vertical = 6.dp),
                color = if (sel == null) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        items(cats.size) { i ->
            val g = cats[i]
            Text(cleanCat(g), Modifier.neon({ onSel(g) }, 18).padding(horizontal = 14.dp, vertical = 6.dp),
                color = if (g == sel) Gold else Color.White, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
fun LiveGuide(rows: List<Pair<String, List<Channel>>>, onPlay: (List<Channel>, Int) -> Unit) {
    var selCat by remember { mutableStateOf<String?>(null) }
    val sel = rows.firstOrNull { it.first == selCat } ?: rows.first()
    Row(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.width(210.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(rows.size) { i ->
                val g = rows[i].first
                Text(g, Modifier.fillMaxWidth().neon({ selCat = g }, 10).padding(12.dp),
                    color = if (g == sel.first) Gold else Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.width(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(sel.second.size) { i ->
                val c = sel.second[i]
                Row(Modifier.fillMaxWidth().neon({ onPlay(sel.second, i) }, 10).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}", Modifier.width(40.dp), color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Box(Modifier.size(44.dp), Alignment.Center) {
                        if (c.logo != null) AsyncImage(c.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        else Text("▶", color = Gold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(c.name, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun GamesPanel(games: List<Game>, loading: Boolean, hasLogin: Boolean, onPlay: (Game) -> Unit) {
    var day by remember { mutableIntStateOf(0) }
    val tf = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    val now = System.currentTimeMillis()
    val cal = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }
    val d0 = cal.timeInMillis + day * 86400000L
    val shown = games.filter { (it.start >= d0 && it.start < d0 + 86400000L) || (day == 0 && it.start < now && it.end > now) }
    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("HOJE", "AMANHÃ").forEachIndexed { i, l ->
                Text(l, Modifier.neon({ day = i }, 10).padding(horizontal = 18.dp, vertical = 8.dp), color = if (i == day) Gold else Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Text("JOGOS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text("${shown.size}", Modifier.background(Color(0xFFD33A3A), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 2.dp), color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
            !hasLogin -> Text("Os jogos do dia usam a programação (EPG) do seu painel. Entre com usuário e senha para ver.", color = Color.White.copy(alpha = 0.7f))
            shown.isEmpty() -> Text("Nenhum jogo encontrado na programação do seu painel para este dia.", color = Color.White.copy(alpha = 0.7f))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown.size) { i ->
                    val g = shown[i]
                    val liveNow = g.start <= now && g.end > now
                    Row(Modifier.fillMaxWidth().neon({ onPlay(g) }, 14).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp), Alignment.Center) {
                            if (g.channel.logo != null) AsyncImage(g.channel.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                            else Text("▶", color = Gold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.width(84.dp)) {
                            Text(tf.format(java.util.Date(g.start)), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text(g.channel.name, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(g.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (g.info.isNotBlank()) Text(g.info, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(if (liveNow) "AO VIVO" else "Agendado",
                            Modifier.background(if (liveNow) Color(0xFFD33A3A) else Color(0xFF3B5BDB), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                            color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/** Tela inicial: menu lateral de ícones, abas em 3D, banner em destaque e prateleiras de cima para baixo. */
@Composable
fun HomeScreen(
    channels: List<Channel>, loading: Boolean, error: String?, tab: Int, onTab: (Int) -> Unit, hidden: Set<String>,
    daysLeft: Int?, games: List<Game>, gamesLoading: Boolean, hasLogin: Boolean, onLoadGames: () -> Unit,
    onPlay: (List<Channel>, Int, Boolean) -> Unit, onSeries: (Channel) -> Unit, onSettings: () -> Unit, onSearch: () -> Unit
) {
    var cat by remember(tab) { mutableStateOf<String?>(null) }
    val live = remember(channels) { channels.filter { it.type == LIVE } }
    val movies = remember(channels) { channels.filter { it.type == MOVIE } }
    val shows = remember(channels) { channels.filter { it.type == SERIES }.distinctBy { it.show } }
    val base0 = when (tab) { 0 -> live; 1 -> movies; else -> shows }
    val rows = remember(base0, hidden) { base0.filter { it.group !in hidden }.groupBy { it.group }.toList() }
    val featured = remember(rows) { rows.randomOrNull()?.second?.filter { it.logo != null }?.randomOrNull() }
    var heroItem by remember(rows) { mutableStateOf(featured) }
    LaunchedEffect(tab) { if (tab == 3) onLoadGames() }
    val click: (List<Channel>, Int) -> Unit = { l, i -> if (tab == 2) onSeries(l[i]) else onPlay(l, i, tab == 0) }
    val tabs = listOf("TV", "FILMES", "SÉRIES", "JOGOS")
    val icons = listOf("📺", "🎬", "📚", "⚽")

    Row(Modifier.fillMaxSize().background(bgBrush)) {
        Column(
            Modifier.fillMaxHeight().width(64.dp).background(Color(0x33000000)).padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("🔍", Modifier.neon(onSearch, 12).padding(10.dp), fontSize = 20.sp)
            icons.forEachIndexed { i, ic ->
                Text(ic, Modifier.alpha(if (i == tab) 1f else 0.55f).neon({ onTab(i) }, 12).padding(10.dp), fontSize = 20.sp)
            }
            Spacer(Modifier.weight(1f))
            Text("⚙", Modifier.neon(onSettings, 12).padding(10.dp), fontSize = 20.sp)
            Image(painterResource(R.drawable.ic_fg), null, Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF0A1A4A)))
        }
        Column(Modifier.weight(1f).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    tabs.forEachIndexed { i, l ->
                        val sel = i == tab
                        Box(Modifier.neon({ onTab(i) }, 14).padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text3D(l, if (sel) GoldHi else Color(0xFFD6E4FF), if (sel) Color(0xFF8A5A00) else Color(0xFF1A2E7A), 17.sp)
                        }
                    }
                }
                if (daysLeft != null) {
                    Text("$daysLeft dias restantes", Modifier.background(Color(0x44FFC21A), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
                        color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (error != null) Text(error, color = Color(0xFFFF6B6B))
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
                tab == 3 -> GamesPanel(games, gamesLoading, hasLogin) { g -> onPlay(listOf(g.channel), 0, true) }
                rows.isEmpty() -> Text("Nada encontrado nesta aba.", color = Color.White.copy(alpha = 0.7f))
                tab == 0 -> LiveGuide(rows) { l, i -> onPlay(l, i, true) }
                else -> {
                    val cats = remember(rows) { rows.map { it.first } }
                    val sel = cat
                    if (sel == null) LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item { heroItem?.let { h -> HeroPanel(h) { if (tab == 2) onSeries(h) else onPlay(listOf(h), 0, false) } } }
                        item { GenreChips(cats, null) { cat = it } }
                        items(rows) { (g, list) ->
                            Text(cleanCat(g), Modifier.padding(bottom = 6.dp), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(4.dp)) {
                                items(list.size) { i -> PosterCard(list[i], { heroItem = list[i] }) { click(list, i) } }
                            }
                        }
                    } else Column {
                        GenreChips(cats, sel) { cat = it }
                        Spacer(Modifier.height(8.dp))
                        val list = rows.firstOrNull { it.first == sel }?.second ?: emptyList()
                        LazyVerticalGrid(GridCells.Adaptive(118.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(list.size) { i -> PosterCard(list[i], {}) { click(list, i) } }
                        }
                    }
                }
            }
        }
    }
}
