package com.pac2.tv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource

private fun ease(x: Float): Float { val v = x.coerceIn(0f, 1f); return v * v * (3 - 2 * v) }

/** Intro estilo cinema: clarão, o logo surge crescendo, um brilho passa por cima e a câmera "mergulha" no fim. Toque ou voltar para pular. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    val finish: () -> Unit = { if (!finished) { finished = true; onDone() } }
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        t.animateTo(1f, tween(4600, easing = LinearEasing))
        finish()
    }
    BackHandler { finish() }
    val p = t.value
    val appear = ease((p - 0.04f) / 0.30f)
    val endK = ease((p - 0.80f) / 0.20f)
    val sc = (0.84f + 0.16f * appear) * (1f + 0.07f * ((p - 0.3f) / 0.5f).coerceIn(0f, 1f)) * (1f + 0.9f * endK)
    val a = appear * (1f - endK)
    val sweep = (p - 0.32f) / 0.34f

    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { finish() } }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val burst = Math.sin(Math.PI * ((p - 0.02f) / 0.30f).coerceIn(0f, 1f)).toFloat()
            val r = size.width * (0.25f + 0.55f * ((p - 0.02f) / 0.30f).coerceIn(0f, 1f))
            if (burst > 0.01f) drawCircle(
                Brush.radialGradient(listOf(Color(0xFF8FB8FF).copy(alpha = 0.55f * burst), Color(0xFF2F6BFF).copy(alpha = 0.25f * burst), Color.Transparent), center, r),
                r, center
            )
        }
        Box(
            Modifier.fillMaxWidth(0.94f).aspectRatio(922f / 452f)
                .graphicsLayer { scaleX = sc; scaleY = sc; alpha = a; compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    if (sweep in 0f..1f) {
                        val x = size.width * (-0.25f + 1.5f * sweep)
                        drawRect(
                            Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                                Offset(x - 130f, 0f), Offset(x + 130f, size.height * 0.35f)),
                            blendMode = BlendMode.SrcAtop
                        )
                    }
                    drawRect(Brush.horizontalGradient(0f to Color.Transparent, 0.06f to Color.White, 0.94f to Color.White, 1f to Color.Transparent), blendMode = BlendMode.DstIn)
                    drawRect(Brush.verticalGradient(0f to Color.Transparent, 0.04f to Color.White, 0.96f to Color.White, 1f to Color.Transparent), blendMode = BlendMode.DstIn)
                }
        ) {
            Image(painterResource(R.drawable.intro_logo), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
    }
}
