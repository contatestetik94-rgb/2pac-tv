package com.pac2.tv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private fun ease(x: Float): Float { val v = x.coerceIn(0f, 1f); return v * v * (3 - 2 * v) }

/** Uma letra em 3D: camadas deslocadas formam a profundidade; a face tem degradê metálico. */
@Composable
private fun Letter3D(ch: Char, a: Float, depth: Float, gold: Boolean, size: TextUnit) {
    val face = if (gold) listOf(Color(0xFFFFF3B0), Color(0xFFFFC21A), Color(0xFFB87800))
               else listOf(Color(0xFFD6E8FF), Color(0xFF3D8BFF), Color(0xFF0A3FD6))
    val side = if (gold) Color(0xFF6B4300) else Color(0xFF0A2377)
    Box(Modifier.alpha(a).graphicsLayer { scaleX = 1.3f - 0.3f * a; scaleY = 1.3f - 0.3f * a }) {
        val n = 10
        for (i in n downTo 1) {
            val d = depth * i / n
            Text(ch.toString(), Modifier.offset(x = (d * 0.8f).dp, y = (d * 1.1f).dp),
                style = TextStyle(color = side, fontSize = size, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic,
                    shadow = if (i == n) Shadow(NavyGlow, Offset.Zero, 40f) else null))
        }
        Text(ch.toString(), style = TextStyle(brush = Brush.verticalGradient(face), fontSize = size, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic))
    }
}

/** Intro só com código: GAEL TV em 3D, brilho que passa pelas letras e estrelinhas. Toque ou voltar para pular. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    val finish: () -> Unit = { if (!finished) { finished = true; onDone() } }
    val t = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        t.animateTo(1f, tween(3600, easing = LinearEasing))
        delay(900)
        fade.animateTo(0f, tween(450))
        finish()
    }
    BackHandler { finish() }
    val ph by rememberInfiniteTransition(label = "tw").animateFloat(0f, 6.2832f, infiniteRepeatable(tween(3000, easing = LinearEasing)), label = "ph")
    val stars = remember { val r = java.util.Random(11); List(40) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }
    val p = t.value

    BoxWithConstraints(
        Modifier.fillMaxSize().background(bgBrush).alpha(fade.value).pointerInput(Unit) { detectTapGestures { finish() } },
        contentAlignment = Alignment.Center
    ) {
        val fs = (maxWidth.value / 8f).coerceIn(40f, 110f).sp
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width; val h = this.size.height
            val rad = h * 0.9f
            drawCircle(Brush.radialGradient(listOf(Color(0xFF2F6BFF).copy(alpha = 0.30f * ease(p / 0.3f)), Color.Transparent), Offset(w / 2, h * 0.95f), rad), rad, Offset(w / 2, h * 0.95f))
            stars.forEachIndexed { i, (sx, sy, ph0) ->
                val tw = ((Math.sin((ph + ph0 * 6.28f + i).toDouble()).toFloat() + 1f) / 2f) * ease((p - 0.15f) / 0.3f)
                val cx = w * sx; val cy = h * (0.15f + 0.7f * sy)
                val r = (3f + 7f * ph0) * tw
                val c = NeonBlueHi.copy(alpha = tw)
                drawLine(c, Offset(cx - r, cy), Offset(cx + r, cy), 2f)
                drawLine(c, Offset(cx, cy - r), Offset(cx, cy + r), 2f)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val s = (p - 0.62f) / 0.28f
            Row(
                Modifier.graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen).drawWithContent {
                    drawContent()
                    if (s in 0f..1f) {
                        val x = this.size.width * (-0.3f + 1.6f * s)
                        drawRect(
                            Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.8f), Color.Transparent),
                                Offset(x - 140f, 0f), Offset(x + 140f, this.size.height * 0.5f)),
                            blendMode = BlendMode.SrcAtop
                        )
                    }
                },
                horizontalArrangement = Arrangement.spacedBy((fs.value * 0.05f).dp)
            ) {
                "GAEL TV".forEachIndexed { i, ch ->
                    if (ch == ' ') Spacer(Modifier.width((fs.value * 0.35f).dp))
                    else Letter3D(ch, ease((p - (0.10f + i * 0.07f)) / 0.18f), 10f * ease((p - 0.38f) / 0.35f), i < 4, fs)
                }
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth(0.5f * ease((p - 0.5f) / 0.3f)).height(3.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, GoldHi, Color.Transparent))))
            Spacer(Modifier.height(12.dp))
            Text("FILMES  •  SÉRIES  •  AO VIVO", Modifier.alpha(ease((p - 0.75f) / 0.2f)), color = NeonBlueHi, letterSpacing = 4.sp, fontSize = 12.sp)
        }
    }
}
