package com.pac2.tv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

/** Intro em vídeo (res/raw/intro.mp4). Toque ou voltar para pular. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var finished by remember { mutableStateOf(false) }
    val finish: () -> Unit = { if (!finished) { finished = true; onDone() } }
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri("android.resource://${ctx.packageName}/${R.raw.intro}"))
            prepare(); playWhenReady = true
        }
    }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_ENDED) finish() }
            override fun onPlayerError(error: PlaybackException) { finish() }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    LaunchedEffect(Unit) { delay(9000); finish() }
    BackHandler { finish() }
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { finish() } }) {
        AndroidView(Modifier.fillMaxSize(), factory = { c ->
            PlayerView(c).apply { this.player = player; useController = false; resizeMode = 0 }
        })
    }
}
