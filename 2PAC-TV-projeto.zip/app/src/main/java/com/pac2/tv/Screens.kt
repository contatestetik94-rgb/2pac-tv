package com.pac2.tv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.geometry.Size
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun IntroScreen(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        t.animateTo(1f, tween(2400, easing = FastOutSlowInEasing))
        delay(700); fade.animateTo(0f, tween(500)); onDone()
    }
    Box(Modifier.fillMaxSize().background(Color.Black).alpha(fade.value), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val rad = size.minDimension * 0.7f
            drawCircle(Brush.radialGradient(listOf(Gold.copy(alpha = 0.30f * t.value), Color.Transparent), c, rad), rad, c)
            val half = size.width * 0.5f * t.value
            if (half > 1f) drawRect(
                Brush.horizontalGradient(listOf(Color.Transparent, GoldHi, Color.Transparent), c.x - half, c.x + half),
                Offset(c.x - half, c.y - 3f), Size(half * 2, 6f)
            )
            val len = size.maxDimension * t.value
            for (i in 0 until 28) {
                val a = (i * 2 * PI / 28).toFloat()
                drawLine(Gold.copy(alpha = 0.14f), c, Offset(c.x + cos(a) * len, c.y + sin(a) * len), 2f)
            }
        }
        Text(neonTitle(60f), Modifier.scale(2.2f - 1.2f * t.value).alpha(t.value),
            fontSize = 96.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
    }
}

val genreKeys = linkedMapOf(
    "Ação" to listOf("ação", "acao", "action"), "Aventura" to listOf("aventura", "adventure"),
    "Comédia" to listOf("comédia", "comedia", "comedy"), "Drama" to listOf("drama"),
    "Terror" to listOf("terror", "horror"), "Ficção" to listOf("ficção", "ficcao", "sci", "fantasia", "fantasy"),
    "Romance" to listOf("romance"), "Animação" to listOf("animação", "animacao", "animation", "desenho", "anime"),
    "Infantil" to listOf("infantil", "kids"), "Documentário" to listOf("document"),
    "Suspense" to listOf("suspense", "thriller", "crime", "policial"), "Família" to listOf("família", "familia", "family"),
    "Lançamentos" to listOf("lançamento", "lancamento", "release"), "Nacional" to listOf("nacional", "brasil")
)
fun genreMatch(group: String, g: String) = genreKeys[g]?.any { group.contains(it, true) } ?: false

@Composable
fun Poster(c: Channel, poster: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(if (poster) 130.dp else 160.dp).neon(onClick)) {
        Box(Modifier.fillMaxWidth().height(if (poster) 190.dp else 90.dp), Alignment.Center) {
            if (c.logo != null) AsyncImage(c.logo, null, Modifier.fillMaxSize().padding(if (poster) 0.dp else 8.dp),
                contentScale = if (poster) ContentScale.Crop else ContentScale.Fit)
            else Text(c.name.take(1).uppercase(), color = Cyan, fontSize = 32.sp, fontWeight = FontWeight.Black)
        }
        Text(c.name, Modifier.padding(8.dp), color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun HomeScreen(
    channels: List<Channel>, loading: Boolean, error: String?, savedUrl: String, tab: Int, onTab: (Int) -> Unit,
    onUrl: (String) -> Unit, onFile: () -> Unit, onPlay: (List<Channel>, Int, Boolean) -> Unit, onSeries: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf(savedUrl) }
    var genre by remember(tab) { mutableStateOf("Todos") }
    val live = remember(channels) { channels.filter { it.type == LIVE } }
    val movies = remember(channels) { channels.filter { it.type == MOVIE } }
    val shows = remember(channels) { channels.filter { it.type == SERIES }.distinctBy { it.show } }
    val base0 = when (tab) { 0 -> live; 1 -> movies; else -> shows }
    val groupsSet = remember(base0) { base0.map { it.group }.distinct() }
    val genres = remember(groupsSet) { genreKeys.keys.filter { g -> groupsSet.any { genreMatch(it, g) } } }
    val rows = remember(base0, genre, query) {
        base0.filter { (genre == "Todos" || genreMatch(it.group, genre)) && it.name.contains(query, true) }
            .groupBy { it.group }.toList()
    }
    val labels = listOf("AO VIVO ${live.size}", "FILMES ${movies.size}", "SÉRIES ${shows.size}")

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF1A0530)))).padding(28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(neonTitle(30f), fontSize = 32.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(20.dp))
            labels.forEachIndexed { i, l ->
                Text(l, Modifier.neon({ onTab(i) }, 20).padding(horizontal = 14.dp, vertical = 8.dp),
                    color = if (i == tab) Cyan else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
            }
            Spacer(Modifier.weight(1f))
            OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Buscar") }, modifier = Modifier.width(180.dp))
            Spacer(Modifier.width(10.dp))
            NeonButton("☰ Lista") { dialog = true }
        }
        Spacer(Modifier.height(14.dp))
        if (tab != 0 && genres.isNotEmpty()) {
            LazyRow(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Todos") + genres) { g ->
                    Text(g, Modifier.neon({ genre = g }, 20).padding(horizontal = 14.dp, vertical = 6.dp),
                        color = if (g == genre) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Cyan) }
            error != null -> Text(error, color = Pink)
            channels.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("Toque em ☰ Lista para carregar sua M3U.", color = Color.White.copy(alpha = 0.7f), fontSize = 18.sp)
            }
            rows.isEmpty() -> Text("Nada encontrado nesta aba.", color = Color.White.copy(alpha = 0.7f))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                items(rows) { (g, list) ->
                    val shown = list.take(60)
                    Text(g, Modifier.padding(bottom = 8.dp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(4.dp)) {
                        items(shown.size) { i ->
                            Poster(shown[i], tab != 0) {
                                if (tab == 2) onSeries(shown[i].show ?: shown[i].name) else onPlay(shown, i, tab == 0)
                            }
                        }
                    }
                }
            }
        }
    }
    if (dialog) AlertDialog(
        onDismissRequest = { dialog = false },
        title = { Text("Carregar lista M3U") },
        text = { OutlinedTextField(url, { url = it }, singleLine = true, placeholder = { Text("http://...") }) },
        confirmButton = { TextButton({ if (url.isNotBlank()) onUrl(url.trim()); dialog = false }) { Text("Carregar URL") } },
        dismissButton = { TextButton({ dialog = false; onFile() }) { Text("Abrir arquivo") } }
    )
}

@Composable
fun SeriesScreen(show: String, eps: List<Channel>, onPlay: (List<Channel>, Int) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF1A0530)))).padding(28.dp)) {
        Text(show, color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("${eps.size} episódios", color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(eps.size) { i ->
                Text(eps[i].name, Modifier.fillMaxWidth().neon({ onPlay(eps, i) }).padding(16.dp), color = Color.White)
            }
        }
    }
}
