package com.pac2.tv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.draw.scale
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val bgBrush = Brush.verticalGradient(listOf(Bg, Color(0xFF1A1200)))

val NeonBlue = Color(0xFF2F6BFF)
val NeonBlueHi = Color(0xFF9DC0FF)
val NavyGlow = Color(0xFF0A2BFF)

/** Intro: fundo azul-marinho degradê, GAEL TV surge em neon com brilho que passa e estrelinhas. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        launch { while (true) withFrameNanos { tick++ } }
        t.animateTo(1f, tween(3800, easing = LinearEasing))
        delay(500); onDone()
    }
    val p = t.value
    val bgA = (p / 0.2f).coerceIn(0f, 1f)
    val a = ((p - 0.12f) / 0.35f).coerceIn(0f, 1f)
    val spread = FastOutSlowInEasing.transform(((p - 0.12f) / 0.6f).coerceIn(0f, 1f))
    val tag = ((p - 0.75f) / 0.2f).coerceIn(0f, 1f)
    val stars = remember { val r = java.util.Random(7); List(16) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }
    Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Box(Modifier.fillMaxSize().alpha(bgA).background(Brush.verticalGradient(listOf(Color(0xFF02040F), Color(0xFF0A1A6E), Color(0xFF1B3FD8)))))
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val rb = h * 0.9f
            drawCircle(Brush.radialGradient(listOf(Color(0xFF3D6BFF).copy(alpha = 0.35f * bgA), Color.Transparent), Offset(w / 2, h), rb), rb, Offset(w / 2, h))
            val k = ((p - 0.35f) / 0.4f).coerceIn(0f, 1f)
            val half = w * 0.28f * k
            if (half > 1f) drawRect(
                Brush.horizontalGradient(listOf(Color.Transparent, NeonBlueHi, Color.Transparent), w / 2 - half, w / 2 + half),
                Offset(w / 2 - half, h / 2 + 22.dp.toPx()), Size(half * 2, 3.dp.toPx())
            )
            val s = (p - 0.45f) / 0.4f
            if (s in 0f..1f) {
                val x = -w * 0.2f + s * w * 1.4f
                drawRect(
                    Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.22f), Color.Transparent), x - 90f, x + 90f),
                    Offset(x - 90f, h / 2 - 65.dp.toPx()), Size(180f, 80.dp.toPx())
                )
            }
            stars.forEachIndexed { i, (sx, sy, ph) ->
                val tw = ((Math.sin(tick * 0.07 + ph * 6.28 + i).toFloat() + 1f) / 2f) * a
                val cx = w * (0.2f + 0.6f * sx); val cy = h / 2 - 25.dp.toPx() + (sy - 0.5f) * 120.dp.toPx()
                val r = (3f + 5f * ph) * tw
                drawLine(NeonBlueHi.copy(alpha = tw), Offset(cx - r, cy), Offset(cx + r, cy), 2f)
                drawLine(NeonBlueHi.copy(alpha = tw), Offset(cx, cy - r), Offset(cx, cy + r), 2f)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.alpha(a).scale(0.92f + 0.08f * a)) {
                val sp = (1f + 7f * spread).sp
                Text("GAEL TV", style = TextStyle(color = Color(0xFF0A2BFF), fontSize = 50.sp, fontWeight = FontWeight.Black,
                    letterSpacing = sp, shadow = Shadow(NavyGlow, Offset.Zero, 90f)), maxLines = 1, softWrap = false)
                Text("GAEL TV", style = TextStyle(color = Color(0xFFEAF2FF), fontSize = 50.sp, fontWeight = FontWeight.Black,
                    letterSpacing = sp, shadow = Shadow(NeonBlue, Offset.Zero, 24f)), maxLines = 1, softWrap = false)
            }
            Spacer(Modifier.height(36.dp))
            Text("FILMES  •  SÉRIES  •  AO VIVO", Modifier.alpha(tag), color = NeonBlueHi, letterSpacing = 4.sp, fontSize = 12.sp)
        }
    }
}

val genreKeys = linkedMapOf(
    "Ação" to listOf("ação", "acao", "action"), "Aventura" to listOf("aventura", "adventure"),
    "Comédia" to listOf("comédia", "comedia", "comedy"), "Drama" to listOf("drama"),
    "Terror" to listOf("terror", "horror"), "Ficção" to listOf("ficção", "ficcao", "sci", "fantasia", "fantasy"),
    "Romance" to listOf("romance"), "Animação" to listOf("animação", "animacao", "animation", "desenho", "anime"),
    "Infantil" to listOf("infantil", "kids"), "Documentário" to listOf("document"),
    "Suspense" to listOf("suspense", "thriller", "crime", "policial"), "Família" to listOf("família", "familia", "family"),
    "Lançamentos" to listOf("lançamento", "lancamento", "release"), "Nacional" to listOf("nacional", "brasil"),
    "Novelas" to listOf("novela"), "Esportes" to listOf("esporte", "sport")
)
fun genreMatch(group: String, g: String) = genreKeys[g]?.any { group.contains(it, true) } ?: false

@Composable
fun Poster(c: Channel, poster: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(if (poster) 130.dp else 160.dp).neon(onClick)) {
        Box(Modifier.fillMaxWidth().height(if (poster) 190.dp else 90.dp), Alignment.Center) {
            if (c.logo != null) AsyncImage(c.logo, null, Modifier.fillMaxSize().padding(if (poster) 0.dp else 8.dp),
                contentScale = if (poster) ContentScale.Crop else ContentScale.Fit)
            else Text(c.name.take(1).uppercase(), color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
        }
        Text(c.name, Modifier.padding(8.dp), color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Hero(c: Channel, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF2A1F00), Color.Transparent)), RoundedCornerShape(16.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (c.logo != null) AsyncImage(c.logo, null, Modifier.width(110.dp).height(160.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(16.dp))
        Column {
            Text("EM DESTAQUE", color = Gold, fontSize = 12.sp, letterSpacing = 3.sp)
            Text(c.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(c.group, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Text("▶ Assistir", Modifier.neon(onClick, 24).padding(horizontal = 22.dp, vertical = 10.dp), color = Gold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HeroBig(c: Channel, onClick: () -> Unit) {
    val bg = Color(0xFF101830)
    Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(16.dp)).background(bg)) {
        if (c.logo != null) AsyncImage(c.logo, null, Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(220.dp), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(bg, bg.copy(alpha = 0.93f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(20.dp).fillMaxWidth(0.6f)) {
            Text(c.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(c.group, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Text("▶ Assistir", Modifier.neon(onClick, 24).padding(horizontal = 22.dp, vertical = 10.dp), color = Gold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HomeScreen(
    channels: List<Channel>, loading: Boolean, error: String?, tab: Int, onTab: (Int) -> Unit, hidden: Set<String>, style: Int,
    onPlay: (List<Channel>, Int, Boolean) -> Unit, onSeries: (Channel) -> Unit, onSettings: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var genre by remember(tab) { mutableStateOf("Todos") }
    var cat by remember(tab, genre) { mutableStateOf<String?>(null) }
    val live = remember(channels) { channels.filter { it.type == LIVE } }
    val movies = remember(channels) { channels.filter { it.type == MOVIE } }
    val shows = remember(channels) { channels.filter { it.type == SERIES }.distinctBy { it.show } }
    val base0 = when (tab) { 0 -> live; 1 -> movies; else -> shows }
    val groupsSet = remember(base0) { base0.map { it.group }.distinct() }
    val genres = remember(groupsSet) { genreKeys.keys.filter { g -> groupsSet.any { genreMatch(it, g) } } }
    val rows = remember(base0, genre, query, hidden) {
        base0.filter { it.group !in hidden && (genre == "Todos" || genreMatch(it.group, genre)) && it.name.contains(query, true) }
            .groupBy { it.group }.toList()
    }
    val featured = remember(rows) { rows.randomOrNull()?.second?.filter { it.logo != null }?.randomOrNull() }
    val catNames = remember(rows) { listOf("Todas") + rows.map { it.first } }
    val flat = remember(rows, cat) { if (cat == null) rows.flatMap { it.second } else rows.firstOrNull { it.first == cat }?.second ?: emptyList() }
    val labels = listOf("AO VIVO ${live.size}", "FILMES ${movies.size}", "SÉRIES ${shows.size}")
    val click: (List<Channel>, Int) -> Unit = { l, i -> if (tab == 2) onSeries(l[i]) else onPlay(l, i, tab == 0) }

    val search: @Composable () -> Unit = {
        OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Buscar") }, modifier = Modifier.width(170.dp))
    }
    val header: @Composable () -> Unit = {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            Text(neonTitle(30f), fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(14.dp))
            NeonButton("⚙", onSettings)
            Spacer(Modifier.width(14.dp))
            labels.forEachIndexed { i, l ->
                Text(l, Modifier.neon({ onTab(i) }, 20).padding(horizontal = 14.dp, vertical = 8.dp),
                    color = if (i == tab) Gold else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
            }
            search()
        }
    }
    val chips: @Composable () -> Unit = {
        if (tab != 0 && genres.isNotEmpty()) {
            LazyRow(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Todos") + genres) { g ->
                    Text(g, Modifier.neon({ genre = g }, 20).padding(horizontal = 14.dp, vertical = 6.dp),
                        color = if (g == genre) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (error != null) Text(error, color = Color(0xFFFF6B6B))
    }
    val shelves: @Composable () -> Unit = {
        chips()
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
            rows.isEmpty() -> Text("Nada encontrado nesta aba.", color = Color.White.copy(alpha = 0.7f))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                if (tab != 0 && featured != null) item {
                    val go = { if (tab == 2) onSeries(featured) else onPlay(listOf(featured), 0, false) }
                    if (style == 1) HeroBig(featured, go) else Hero(featured, go)
                }
                items(rows) { (g, list) ->
                    Text(g, Modifier.padding(bottom = 8.dp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(4.dp)) {
                        items(list.size) { i -> Poster(list[i], tab != 0) { click(list, i) } }
                    }
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(bgBrush)) {
        when (style) {
            1 -> Row(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxHeight().width(64.dp).background(Color(0x22FFFFFF)).padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("GAEL", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    listOf("📺", "🎬", "📚").forEachIndexed { i, ic ->
                        Text(ic, Modifier.alpha(if (i == tab) 1f else 0.5f).neon({ onTab(i) }, 12).padding(10.dp), fontSize = 20.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("⚙", Modifier.neon(onSettings, 12).padding(10.dp), fontSize = 20.sp)
                }
                Column(Modifier.weight(1f).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(labels[tab], color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.weight(1f))
                        search()
                    }
                    Spacer(Modifier.height(12.dp))
                    shelves()
                }
            }
            2 -> Column(Modifier.fillMaxSize().padding(24.dp)) {
                header()
                Spacer(Modifier.height(12.dp))
                chips()
                LazyRow(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(catNames) { n ->
                        val sel = (cat ?: "Todas") == n
                        Text(n, Modifier.neon({ cat = if (n == "Todas") null else n }, 20).padding(horizontal = 14.dp, vertical = 6.dp),
                            color = if (sel) Gold else Color.White, fontSize = 13.sp, maxLines = 1)
                    }
                }
                when {
                    loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
                    flat.isEmpty() -> Text("Nada encontrado nesta aba.", color = Color.White.copy(alpha = 0.7f))
                    else -> LazyVerticalGrid(GridCells.Adaptive(if (tab == 0) 160.dp else 130.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(flat.size) { i -> Poster(flat[i], tab != 0) { click(flat, i) } }
                    }
                }
            }
            else -> Column(Modifier.fillMaxSize().padding(24.dp)) {
                header()
                Spacer(Modifier.height(14.dp))
                shelves()
            }
        }
    }
}

@Composable
fun LoginScreen(
    srv0: String, usr0: String, pwd0: String, loading: Boolean, error: String?,
    onLogin: (String, String, String) -> Unit, onM3u: (String) -> Unit, onFile: () -> Unit, onBack: (() -> Unit)?
) {
    var mode by remember { mutableIntStateOf(0) }
    var srv by remember { mutableStateOf(srv0) }
    var usr by remember { mutableStateOf(usr0) }
    var pwd by remember { mutableStateOf(pwd0) }
    var m3u by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(bgBrush).verticalScroll(rememberScrollState()).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(neonTitle(40f), fontSize = 44.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        Row {
            Text("Usuário e senha", Modifier.neon({ mode = 0 }, 20).padding(horizontal = 16.dp, vertical = 8.dp), color = if (mode == 0) Gold else Color.White)
            Spacer(Modifier.width(10.dp))
            Text("Lista M3U", Modifier.neon({ mode = 1 }, 20).padding(horizontal = 16.dp, vertical = 8.dp), color = if (mode == 1) Gold else Color.White)
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.widthIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (mode == 0) {
                OutlinedTextField(srv, { srv = it }, label = { Text("Servidor (ex: http://painel.com:8080)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(usr, { usr = it }, label = { Text("Usuário") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pwd, { pwd = it }, label = { Text("Senha") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                NeonButton("Entrar") { if (srv.isNotBlank() && usr.isNotBlank()) onLogin(srv, usr, pwd) }
            } else {
                OutlinedTextField(m3u, { m3u = it }, label = { Text("URL da lista M3U") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                NeonButton("Carregar lista") { if (m3u.isNotBlank()) onM3u(m3u.trim()) }
                NeonButton("Abrir arquivo M3U", onFile)
            }
            if (loading) CircularProgressIndicator(color = Gold)
            if (error != null) Text(error, color = Color(0xFFFF6B6B))
            if (onBack != null) NeonButton("‹ Voltar", onBack)
        }
    }
}

@Composable
fun SettingRow(icon: String, title: String, value: String? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().neon(onClick, 14).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 20.sp)
        Spacer(Modifier.width(14.dp))
        Text(title, Modifier.weight(1f), color = Color.White, fontSize = 17.sp)
        if (value != null) Text(value, color = Color.Gray, fontSize = 14.sp)
        Text("  ›", color = Color.White, fontSize = 20.sp)
    }
}

@Composable
fun SettingsScreen(
    host: String, status: String, fmt: String, hasLogin: Boolean, groups: List<String>, hidden: Set<String>,
    onHidden: (Set<String>) -> Unit, onFmt: (String) -> Unit, onPlaylist: () -> Unit, onRefresh: () -> Unit,
    onClear: () -> Unit, onLogout: () -> Unit, onBack: () -> Unit, uiName: String, onUi: () -> Unit
) {
    BackHandler(onBack = onBack)
    var cats by remember { mutableStateOf(false) }
    val card = Modifier.fillMaxWidth().background(Color(0xFF151515), RoundedCornerShape(20.dp)).padding(8.dp)
    Column(Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonButton("‹ Voltar", onBack)
            Spacer(Modifier.weight(1f))
            Text("Conta", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(60.dp).background(Gold, CircleShape), Alignment.Center) { Text("👤", fontSize = 26.sp) }
            Spacer(Modifier.width(16.dp))
            Text("Olá, Meu perfil", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Column(card.padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row { Text("Status da assinatura:", Modifier.weight(1f), color = Gold, fontWeight = FontWeight.Bold); Text(status, color = Gold, fontWeight = FontWeight.Bold) }
            Row { Text("Fornecida por:", Modifier.weight(1f), color = Gold, fontWeight = FontWeight.Bold); Text(host.ifBlank { "seu provedor" }, color = Gold, fontWeight = FontWeight.Bold) }
        }
        Column(card) {
            SettingRow("📋", "Playlist (login / M3U)", onClick = onPlaylist)
            SettingRow("🎨", "Estilo da interface", uiName, onUi)
            if (hasLogin) SettingRow("🔄", "Atualizar lista", onClick = onRefresh)
            SettingRow("⇄", "Alterar formato de fluxo", fmt.uppercase()) { onFmt(if (fmt == "m3u8") "ts" else "m3u8") }
            SettingRow("👁", "Gerenciar categorias", "${hidden.size} ocultas") { cats = true }
            SettingRow("🗑", "Limpar armazenamento", onClick = onClear)
        }
        Column(card) { SettingRow("⎋", "Sair da conta", onClick = onLogout) }
    }
    if (cats) AlertDialog(
        onDismissRequest = { cats = false },
        title = { Text("Gerenciar categorias") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(groups) { g ->
                    val on = g !in hidden
                    Row(Modifier.fillMaxWidth().neon({ onHidden(if (on) hidden + g else hidden - g) }, 8).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = on, onCheckedChange = null)
                        Spacer(Modifier.width(8.dp))
                        Text(g, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        confirmButton = { TextButton({ cats = false }) { Text("OK") } }
    )
}

@Composable
fun SeriesScreen(show: String, eps: List<Channel>, onPlay: (List<Channel>, Int) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(bgBrush).padding(28.dp)) {
        Text(show, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("${eps.size} episódios", color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(eps.size) { i ->
                Text(eps[i].name, Modifier.fillMaxWidth().neon({ onPlay(eps, i) }).padding(16.dp), color = Color.White)
            }
        }
    }
}

@Composable
fun UiPreview(style: Int, modifier: Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF0B0B14))) {
        val w = size.width; val h = size.height
        val dim = Color(0x33FFFFFF); val hero = Color(0x55FFC21A)
        fun box(x: Float, y: Float, bw: Float, bh: Float, c: Color) =
            drawRoundRect(c, Offset(x * w, y * h), Size(bw * w, bh * h), CornerRadius(6f, 6f))
        when (style) {
            0 -> {
                box(0.04f, 0.06f, 0.2f, 0.06f, Gold); box(0.3f, 0.06f, 0.12f, 0.06f, dim); box(0.45f, 0.06f, 0.12f, 0.06f, dim)
                box(0.04f, 0.17f, 0.92f, 0.3f, hero)
                for (r in 0..1) for (i in 0..5) box(0.04f + i * 0.155f, 0.54f + r * 0.23f, 0.14f, 0.19f, dim)
            }
            1 -> {
                box(0f, 0f, 0.08f, 1f, Color(0x22FFFFFF))
                for (i in 0..3) box(0.02f, 0.1f + i * 0.12f, 0.04f, 0.07f, Gold)
                box(0.12f, 0.06f, 0.84f, 0.42f, hero); box(0.14f, 0.34f, 0.12f, 0.07f, Gold)
                for (i in 0..4) box(0.12f + i * 0.17f, 0.56f, 0.15f, 0.38f, dim)
            }
            else -> {
                box(0.04f, 0.06f, 0.2f, 0.06f, Gold)
                for (i in 0..3) box(0.04f + i * 0.14f, 0.17f, 0.12f, 0.06f, dim)
                for (r in 0..2) for (i in 0..6) box(0.04f + i * 0.135f, 0.3f + r * 0.23f, 0.12f, 0.2f, dim)
            }
        }
    }
}

@Composable
fun UiStyleScreen(style: Int, first: Boolean, onSelect: (Int) -> Unit, onNext: () -> Unit, onBack: (() -> Unit)?) {
    if (onBack != null) BackHandler(onBack = onBack)
    val names = listOf("MODERNA", "FUTURO", "SIMPLES")
    val desc = listOf(
        "Abas no topo, destaque e prateleiras por categoria, no estilo dos apps de streaming.",
        "Menu lateral com ícones, banner grande em destaque e prateleiras de filmes.",
        "Grade de pôsteres com categorias em botões. Leve e rápida."
    )
    Column(Modifier.fillMaxSize().background(bgBrush).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(neonTitle(30f), fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        Text("Selecione a interface que prefere", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Você pode mudar depois em Configurações → Estilo da interface.", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        UiPreview(style, Modifier.fillMaxWidth().widthIn(max = 420.dp).aspectRatio(16f / 9f))
        Spacer(Modifier.height(10.dp))
        Text(names[style], color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text(desc[style], Modifier.widthIn(max = 420.dp), color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp)
        Spacer(Modifier.height(14.dp))
        names.forEachIndexed { i, n ->
            Row(Modifier.fillMaxWidth().widthIn(max = 420.dp).neon({ onSelect(i) }, 10).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(n, Modifier.weight(1f), color = if (i == style) Gold else Color.White, fontWeight = FontWeight.Bold)
                if (i == style) Text("✓", color = Gold, fontSize = 20.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Row {
            if (onBack != null) { NeonButton("‹ Voltar", onBack); Spacer(Modifier.width(12.dp)) }
            NeonButton(if (first) "Próximo ›" else "Salvar", onNext)
        }
    }
}
