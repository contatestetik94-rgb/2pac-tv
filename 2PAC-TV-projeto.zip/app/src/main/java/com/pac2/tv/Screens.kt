package com.pac2.tv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.draw.scale
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val bgBrush = Brush.verticalGradient(listOf(Color(0xFF0D1233), Color(0xFF050716)))

val NeonBlue = Color(0xFF2F6BFF)
val NeonBlueHi = Color(0xFF9DC0FF)
val NavyGlow = Color(0xFF0A2BFF)

/** Intro: fundo azul-marinho degradê, GAEL TV surge em neon com brilho que passa e estrelinhas. */
val genreKeys = linkedMapOf(
    "Ação" to listOf("ação", "acao", "action"), "Aventura" to listOf("aventura", "adventure"),
    "Comédia" to listOf("comédia", "comedia", "comedy"), "Drama" to listOf("drama"),
    "Terror" to listOf("terror", "horror"), "Ficção" to listOf("ficção", "ficcao", "sci", "fantasia", "fantasy"),
    "Romance" to listOf("romance"), "Animação" to listOf("animação", "animacao", "animation", "desenho", "anime"),
    "Infantil" to listOf("infantil", "kids"), "Documentário" to listOf("document"),
    "Suspense" to listOf("suspense", "thriller", "crime", "policial"), "Família" to listOf("família", "familia", "family"),
    "Lançamentos" to listOf("lançamento", "lancamento", "release"), "Nacional" to listOf("nacional", "brasil"),
    "Novelas" to listOf("novela"), "Esportes" to listOf("esporte", "sport")
)
fun genreMatch(group: String, g: String) = genreKeys[g]?.any { group.contains(it, true) } ?: false

@Composable
fun SearchScreen(channels: List<Channel>, hidden: Set<String>, onPlay: (List<Channel>, Int, Boolean) -> Unit,
                 onSeries: (Channel) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var q by remember { mutableStateOf("") }
    val res = remember(channels, q) {
        if (q.length < 2) emptyList() else channels.filter { it.group !in hidden && it.name.contains(q, true) }.take(120)
    }
    BoxWithConstraints(Modifier.fillMaxSize().background(bgBrush).padding(20.dp)) {
        val wide = maxWidth > 600.dp
        val keyboard: @Composable () -> Unit = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("‹", Modifier.width(54.dp).neon(onBack, 8).padding(vertical = 8.dp), color = Gold, textAlign = TextAlign.Center)
                    Text("⌫", Modifier.width(54.dp).neon({ q = q.dropLast(1) }, 8).padding(vertical = 8.dp), color = Color.White, textAlign = TextAlign.Center)
                    Text("␣", Modifier.width(54.dp).neon({ q += " " }, 8).padding(vertical = 8.dp), color = Color.White, textAlign = TextAlign.Center)
                }
                "abcdefghijklmnopqrstuvwxyz1234567890".chunked(6).forEach { line ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        line.forEach { ch ->
                            Text(ch.toString(), Modifier.width(36.dp).neon({ q += ch }, 8).padding(vertical = 8.dp), color = Color.White, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
        val results: @Composable (Modifier) -> Unit = { m ->
            Column(m) {
                Text(if (q.isEmpty()) "Digite para buscar" else q, Modifier.fillMaxWidth().background(Color(0x22FFFFFF), RoundedCornerShape(10.dp)).padding(12.dp),
                    color = if (q.isEmpty()) Color.Gray else Color.White, fontSize = 18.sp)
                Spacer(Modifier.height(10.dp))
                when {
                    q.length < 2 -> Text("Use o teclado para buscar filmes, séries e canais.", color = Color.White.copy(alpha = 0.6f))
                    res.isEmpty() -> Text("Nada encontrado.", color = Color.White.copy(alpha = 0.6f))
                    else -> LazyVerticalGrid(GridCells.Adaptive(130.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(res.size) { i ->
                            val c = res[i]
                            Poster(c, c.type != LIVE) { if (c.type == SERIES) onSeries(c) else onPlay(res, i, c.type == LIVE) }
                        }
                    }
                }
            }
        }
        if (wide) Row(Modifier.fillMaxSize()) {
            Box(Modifier.width(260.dp).verticalScroll(rememberScrollState())) { keyboard() }
            Spacer(Modifier.width(18.dp))
            results(Modifier.weight(1f))
        } else Column(Modifier.fillMaxSize()) {
            keyboard()
            Spacer(Modifier.height(12.dp))
            results(Modifier.weight(1f))
        }
    }
}

@Composable
fun LoginScreen(
    srv0: String, usr0: String, pwd0: String, loading: Boolean, error: String?,
    onLogin: (String, String, String) -> Unit, onM3u: (String) -> Unit, onFile: () -> Unit, onBack: (() -> Unit)?
) {
    var mode by remember { mutableIntStateOf(0) }
    var srv by remember { mutableStateOf(srv0) }
    var usr by remember { mutableStateOf(usr0) }
    var pwd by remember { mutableStateOf(pwd0) }
    var m3u by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(bgBrush).verticalScroll(rememberScrollState()).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(neonTitle(40f), fontSize = 44.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        Row {
            Text("Usuário e senha", Modifier.neon({ mode = 0 }, 20).padding(horizontal = 16.dp, vertical = 8.dp), color = if (mode == 0) Gold else Color.White)
            Spacer(Modifier.width(10.dp))
            Text("Lista M3U", Modifier.neon({ mode = 1 }, 20).padding(horizontal = 16.dp, vertical = 8.dp), color = if (mode == 1) Gold else Color.White)
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.widthIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (mode == 0) {
                OutlinedTextField(srv, { srv = it }, label = { Text("Servidor (ex: http://painel.com:8080)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(usr, { usr = it }, label = { Text("Usuário") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pwd, { pwd = it }, label = { Text("Senha") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                NeonButton("Entrar") { if (srv.isNotBlank() && usr.isNotBlank()) onLogin(srv, usr, pwd) }
            } else {
                OutlinedTextField(m3u, { m3u = it }, label = { Text("URL da lista M3U") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                NeonButton("Carregar lista") { if (m3u.isNotBlank()) onM3u(m3u.trim()) }
                NeonButton("Abrir arquivo M3U", onFile)
            }
            if (loading) CircularProgressIndicator(color = Gold)
            if (error != null) Text(error, color = Color(0xFFFF6B6B))
            if (onBack != null) NeonButton("‹ Voltar", onBack)
        }
    }
}

@Composable
fun SettingCard(icon: String, title: String, sub: String, on: Boolean? = null, danger: Boolean = false, onClick: () -> Unit) {
    val c = when { danger -> Color(0xFF7A1B1B); on == true -> Color(0xFF138A4B); on == false -> Color(0xFF2B2B2B); else -> Color(0xFF1C1C1C) }
    Row(Modifier.fillMaxWidth().neon(onClick, 16).background(c).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
        }
        if (on != null) Text(if (on) "ATIVADO" else "DESATIVADO", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SettingsScreen(
    host: String, status: String, fmt: String, hasLogin: Boolean, groups: List<String>, hidden: Set<String>,
    onHidden: (Set<String>) -> Unit, onFmt: (String) -> Unit, onPlaylist: () -> Unit, onRefresh: () -> Unit,
    onClear: () -> Unit, onLogout: () -> Unit, onBack: () -> Unit,
    smooth: Boolean, onSmooth: (Boolean) -> Unit, ratio: Int, onRatio: (Int) -> Unit,
    layout: Int, onLayout: (Int) -> Unit, hdOnly: Boolean, onHdOnly: (Boolean) -> Unit, preview: Boolean, onPreview: (Boolean) -> Unit
) {
    BackHandler(onBack = onBack)
    var cats by remember { mutableStateOf(false) }
    val ratioNames = listOf("Ajustar", "Preencher", "Zoom")
    val dim = Color.White.copy(alpha = 0.6f)
    Column(Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonButton("‹ Voltar", onBack)
            Spacer(Modifier.width(16.dp))
            Text("Configurações", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxWidth().background(Color(0xFF1C1C1C), RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row { Text("Status da assinatura:", Modifier.weight(1f), color = Gold, fontWeight = FontWeight.Bold); Text(status, color = Gold, fontWeight = FontWeight.Bold) }
            Row { Text("Fornecida por:", Modifier.weight(1f), color = Gold, fontWeight = FontWeight.Bold); Text(host.ifBlank { "seu provedor" }, color = Gold, fontWeight = FontWeight.Bold) }
        }
        Text("Layout e personalização", Modifier.padding(top = 8.dp), color = dim, fontSize = 13.sp)
        SettingCard("🧩", "Layout da interface", if (layout == 0) "Atual: menu lateral com banner (toque para trocar)" else "Atual: painel Início com atalhos (toque para trocar)") { onLayout(1 - layout) }
        SettingCard("📶", "Somente HD, Full HD e 4K", "Esconde os canais SD da lista", on = hdOnly) { onHdOnly(!hdOnly) }
        SettingCard("📺", "Prévia do canal ao lado da lista", "Mostra o canal tocando enquanto você navega (desative se travar)", on = preview) { onPreview(!preview) }
        SettingCard("👁", "Gerenciar categorias", "${hidden.size} categorias ocultas") { cats = true }
        Text("Reprodução", Modifier.padding(top = 8.dp), color = dim, fontSize = 13.sp)
        SettingCard("⚙", "Reprodução suave", "Buffer maior: mais estável em conexões lentas, usa mais memória", on = smooth) { onSmooth(!smooth) }
        SettingCard("⇄", "Formato de fluxo", "Canais ao vivo em ${fmt.uppercase()} (toque para alternar)") { onFmt(if (fmt == "m3u8") "ts" else "m3u8") }
        SettingCard("▭", "Proporção do vídeo", "Atual: ${ratioNames[ratio]} (toque para alternar)") { onRatio((ratio + 1) % 3) }
        Text("Conta e dados", Modifier.padding(top = 8.dp), color = dim, fontSize = 13.sp)
        SettingCard("📋", "Playlist (login / M3U)", "Trocar usuário, senha ou lista", onClick = onPlaylist)
        if (hasLogin) SettingCard("🔄", "Atualizar lista", "Buscar canais, filmes e séries de novo", onClick = onRefresh)
        SettingCard("🗑", "Limpar armazenamento", "Apaga imagens salvas e arquivos temporários", onClick = onClear)
        SettingCard("⎋", "Sair da conta", "Remove o login deste aparelho", danger = true, onClick = onLogout)
    }
    if (cats) AlertDialog(
        onDismissRequest = { cats = false },
        title = { Text("Gerenciar categorias") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(groups) { g ->
                    val on = g !in hidden
                    Row(Modifier.fillMaxWidth().neon({ onHidden(if (on) hidden + g else hidden - g) }, 8).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = on, onCheckedChange = null)
                        Spacer(Modifier.width(8.dp))
                        Text(g, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        confirmButton = { TextButton({ cats = false }) { Text("OK") } }
    )
}

@Composable
fun SeriesScreen(show: String, eps: List<Channel>, onPlay: (List<Channel>, Int) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(bgBrush).padding(28.dp)) {
        Text(show, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("${eps.size} episódios", color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(eps.size) { i ->
                Text(eps[i].name, Modifier.fillMaxWidth().neon({ onPlay(eps, i) }).padding(16.dp), color = Color.White)
            }
        }
    }
}

