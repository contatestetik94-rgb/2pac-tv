package com.pac2.tv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val bgBrush = Brush.verticalGradient(listOf(Bg, Color(0xFF1A1200)))

/** Intro: ruído de TV que vai se desfazendo até o logo dourado acender. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        launch { while (true) withFrameNanos { tick++ } }
        t.animateTo(1f, tween(3000, easing = LinearEasing))
        delay(700); onDone()
    }
    val p = t.value
    val flick = if (p < 0.7f) { if (java.util.Random((tick / 3).toLong()).nextFloat() < p + 0.15f) 1f else 0.08f } else 1f
    val glow = ((p - 0.6f) / 0.4f).coerceIn(0f, 1f)
    Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val rnd = java.util.Random(tick.toLong())
            val n = (900 * (1f - p).coerceAtLeast(0f)).toInt() + 40
            repeat(n) {
                val g = rnd.nextFloat()
                drawRect(Color(g, g, g, 0.5f), Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height), Size(2f + rnd.nextFloat() * 14f, 2f))
            }
            val ly = ((tick * 7) % size.height.toInt().coerceAtLeast(1)).toFloat()
            drawRect(Color.White.copy(alpha = 0.04f), Offset(0f, ly), Size(size.width, 24f))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(neonTitle(50f * glow), Modifier.alpha(flick), fontSize = 84.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
            Spacer(Modifier.height(12.dp))
            Text("FILMES  •  SÉRIES  •  AO VIVO", Modifier.alpha(glow), color = Color.White.copy(alpha = 0.85f), letterSpacing = 5.sp, fontSize = 14.sp)
        }
    }
}

val genreKeys = linkedMapOf(
    "Ação" to listOf("ação", "acao", "action"), "Aventura" to listOf("aventura", "adventure"),
    "Comédia" to listOf("comédia", "comedia", "comedy"), "Drama" to listOf("drama"),
    "Terror" to listOf("terror", "horror"), "Ficção" to listOf("ficção", "ficcao", "sci", "fantasia", "fantasy"),
    "Romance" to listOf("romance"), "Animação" to listOf("animação", "animacao", "animation", "desenho", "anime"),
    "Infantil" to listOf("infantil", "kids"), "Documentário" to listOf("document"),
    "Suspense" to listOf("suspense", "thriller", "crime", "policial"), "Família" to listOf("família", "familia", "family"),
    "Lançamentos" to listOf("lançamento", "lancamento", "release"), "Nacional" to listOf("nacional", "brasil"),
    "Novelas" to listOf("novela"), "Esportes" to listOf("esporte", "sport")
)
fun genreMatch(group: String, g: String) = genreKeys[g]?.any { group.contains(it, true) } ?: false

@Composable
fun Poster(c: Channel, poster: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(if (poster) 130.dp else 160.dp).neon(onClick)) {
        Box(Modifier.fillMaxWidth().height(if (poster) 190.dp else 90.dp), Alignment.Center) {
            if (c.logo != null) AsyncImage(c.logo, null, Modifier.fillMaxSize().padding(if (poster) 0.dp else 8.dp),
                contentScale = if (poster) ContentScale.Crop else ContentScale.Fit)
            else Text(c.name.take(1).uppercase(), color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
        }
        Text(c.name, Modifier.padding(8.dp), color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Hero(c: Channel, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF2A1F00), Color.Transparent)), RoundedCornerShape(16.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (c.logo != null) AsyncImage(c.logo, null, Modifier.width(110.dp).height(160.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(16.dp))
        Column {
            Text("EM DESTAQUE", color = Gold, fontSize = 12.sp, letterSpacing = 3.sp)
            Text(c.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(c.group, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Text("▶ Assistir", Modifier.neon(onClick, 24).padding(horizontal = 22.dp, vertical = 10.dp), color = Gold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HomeScreen(
    channels: List<Channel>, loading: Boolean, error: String?, tab: Int, onTab: (Int) -> Unit, hidden: Set<String>,
    onPlay: (List<Channel>, Int, Boolean) -> Unit, onSeries: (Channel) -> Unit, onSettings: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var genre by remember(tab) { mutableStateOf("Todos") }
    val live = remember(channels) { channels.filter { it.type == LIVE } }
    val movies = remember(channels) { channels.filter { it.type == MOVIE } }
    val shows = remember(channels) { channels.filter { it.type == SERIES }.distinctBy { it.show } }
    val base0 = when (tab) { 0 -> live; 1 -> movies; else -> shows }
    val groupsSet = remember(base0) { base0.map { it.group }.distinct() }
    val genres = remember(groupsSet) { genreKeys.keys.filter { g -> groupsSet.any { genreMatch(it, g) } } }
    val rows = remember(base0, genre, query, hidden) {
        base0.filter { it.group !in hidden && (genre == "Todos" || genreMatch(it.group, genre)) && it.name.contains(query, true) }
            .groupBy { it.group }.toList()
    }
    val featured = remember(rows) { rows.randomOrNull()?.second?.filter { it.logo != null }?.randomOrNull() }
    val labels = listOf("AO VIVO ${live.size}", "FILMES ${movies.size}", "SÉRIES ${shows.size}")

    Column(Modifier.fillMaxSize().background(bgBrush).padding(24.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            Text(neonTitle(30f), fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(14.dp))
            NeonButton("⚙", onSettings)
            Spacer(Modifier.width(14.dp))
            labels.forEachIndexed { i, l ->
                Text(l, Modifier.neon({ onTab(i) }, 20).padding(horizontal = 14.dp, vertical = 8.dp),
                    color = if (i == tab) Gold else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
            }
            OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Buscar") }, modifier = Modifier.width(170.dp))
        }
        Spacer(Modifier.height(14.dp))
        if (tab != 0 && genres.isNotEmpty()) {
            LazyRow(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Todos") + genres) { g ->
                    Text(g, Modifier.neon({ genre = g }, 20).padding(horizontal = 14.dp, vertical = 6.dp),
                        color = if (g == genre) Gold else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (error != null) Text(error, color = Color(0xFFFF6B6B))
        when {
            loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
            rows.isEmpty() -> Text("Nada encontrado nesta aba.", color = Color.White.copy(alpha = 0.7f))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                if (tab != 0 && featured != null) item {
                    Hero(featured) { if (tab == 2) onSeries(featured) else onPlay(listOf(featured), 0, false) }
                }
                items(rows) { (g, list) ->
                    Text(g, Modifier.padding(bottom = 8.dp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(4.dp)) {
                        items(list.size) { i ->
                            Poster(list[i], tab != 0) {
                                if (tab == 2) onSeries(list[i]) else onPlay(list, i, tab == 0)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(
    srv0: String, usr0: String, pwd0: String, loading: Boolean, error: String?,
    onLogin: (String, String, String) -> Unit, onM3u: (String) -> Unit, onFile: () -> Unit, onBack: (() -> Unit)?
) {
    var mode by remember { mutableIntStateOf(0) }
    var srv by remember { mutableStateOf(srv0) }
    var usr by remember { mutableStateOf(usr0) }
    var pwd by remember { mutableStateOf(pwd0) }
    var m3u by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(bgBrush).verticalScroll(rememberScrollState()).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(neonTitle(40f), fontSize = 44.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        Row {
            Text("Usuário e senha", Modifier.neon({ mode = 0 }, 20).padding(horizontal = 16.dp, vertical = 8.dp), color = if (mode == 0) Gold else Color.White)
            Spacer(Modifier.width(10.dp))
            Text("Lista M3U", Modifier.neon({ mode = 1 }, 20).padding(horizontal = 16.dp, vertical = 8.dp), color = if (mode == 1) Gold else Color.White)
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.widthIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (mode == 0) {
                OutlinedTextField(srv, { srv = it }, label = { Text("Servidor (ex: http://painel.com:8080)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(usr, { usr = it }, label = { Text("Usuário") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pwd, { pwd = it }, label = { Text("Senha") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                NeonButton("Entrar") { if (srv.isNotBlank() && usr.isNotBlank()) onLogin(srv, usr, pwd) }
            } else {
                OutlinedTextField(m3u, { m3u = it }, label = { Text("URL da lista M3U") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                NeonButton("Carregar lista") { if (m3u.isNotBlank()) onM3u(m3u.trim()) }
                NeonButton("Abrir arquivo M3U", onFile)
            }
            if (loading) CircularProgressIndicator(color = Gold)
            if (error != null) Text(error, color = Color(0xFFFF6B6B))
            if (onBack != null) NeonButton("‹ Voltar", onBack)
        }
    }
}

@Composable
fun SettingRow(icon: String, title: String, value: String? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().neon(onClick, 14).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 20.sp)
        Spacer(Modifier.width(14.dp))
        Text(title, Modifier.weight(1f), color = Color.White, fontSize = 17.sp)
        if (value != null) Text(value, color = Color.Gray, fontSize = 14.sp)
        Text("  ›", color = Color.White, fontSize = 20.sp)
    }
}

@Composable
fun SettingsScreen(
    host: String, status: String, fmt: String, hasLogin: Boolean, groups: List<String>, hidden: Set<String>,
    onHidden: (Set<String>) -> Unit, onFmt: (String) -> Unit, onPlaylist: () -> Unit, onRefresh: () -> Unit,
    onClear: () -> Unit, onLogout: () -> Unit, onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    var cats by remember { mutableStateOf(false) }
    val card = Modifier.fillMaxWidth().background(Color(0xFF151515), RoundedCornerShape(20.dp)).padding(8.dp)
    Column(Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeonButton("‹ Voltar", onBack)
            Spacer(Modifier.weight(1f))
            Text("Conta", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(60.dp).background(Gold, CircleShape), Alignment.Center) { Text("👤", fontSize = 26.sp) }
            Spacer(Modifier.width(16.dp))
            Text("Olá, Meu perfil", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Column(card.padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row { Text("Status da assinatura:", Modifier.weight(1f), color = Gold, fontWeight = FontWeight.Bold); Text(status, color = Gold, fontWeight = FontWeight.Bold) }
            Row { Text("Fornecida por:", Modifier.weight(1f), color = Gold, fontWeight = FontWeight.Bold); Text(host.ifBlank { "seu provedor" }, color = Gold, fontWeight = FontWeight.Bold) }
        }
        Column(card) {
            SettingRow("📋", "Playlist (login / M3U)", onClick = onPlaylist)
            if (hasLogin) SettingRow("🔄", "Atualizar lista", onClick = onRefresh)
            SettingRow("⇄", "Alterar formato de fluxo", fmt.uppercase()) { onFmt(if (fmt == "m3u8") "ts" else "m3u8") }
            SettingRow("👁", "Gerenciar categorias", "${hidden.size} ocultas") { cats = true }
            SettingRow("🗑", "Limpar armazenamento", onClick = onClear)
        }
        Column(card) { SettingRow("⎋", "Sair da conta", onClick = onLogout) }
    }
    if (cats) AlertDialog(
        onDismissRequest = { cats = false },
        title = { Text("Gerenciar categorias") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(groups) { g ->
                    val on = g !in hidden
                    Row(Modifier.fillMaxWidth().neon({ onHidden(if (on) hidden + g else hidden - g) }, 8).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = on, onCheckedChange = null)
                        Spacer(Modifier.width(8.dp))
                        Text(g, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        confirmButton = { TextButton({ cats = false }) { Text("OK") } }
    )
}

@Composable
fun SeriesScreen(show: String, eps: List<Channel>, onPlay: (List<Channel>, Int) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(bgBrush).padding(28.dp)) {
        Text(show, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("${eps.size} episódios", color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(eps.size) { i ->
                Text(eps[i].name, Modifier.fillMaxWidth().neon({ onPlay(eps, i) }).padding(16.dp), color = Color.White)
            }
        }
    }
}
